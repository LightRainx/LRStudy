package com.lrstudy.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * LRStudy v1.7 Android shell.
 *
 * A single-file copy of the web app is served from a virtual HTTPS origin via
 * WebViewAssetLoader, so IndexedDB/localStorage get a normal secure origin.
 * Native bridges handle camera/file pickers, theme-aware system bars, and
 * saving generated PDF/ZIP blobs into Downloads/LRStudy.
 */
public class MainActivity extends Activity {
    static final int REQUEST_FILE = 4101;
    static final int REQUEST_CAMERA = 4102;
    static final int REQUEST_STORAGE = 4103;
    private static final String BRIDGE_NAME = "LRNative";
    private static final String APP_URL =
            "https://appassets.androidplatform.net/assets/LRStudy1.7.html";

    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private View splash;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraOutputUri;
    private File cameraOutputFile;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        boolean systemDark = (getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        applySystemTheme(systemDark);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(systemDark ? Color.BLACK : Color.WHITE);

        webView = new WebView(this);
        webView.setBackgroundColor(systemDark ? Color.BLACK : Color.WHITE);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        splash = buildSplash(systemDark);
        root.addView(splash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);
        configureWebView();
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        if (Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    REQUEST_STORAGE);
        }

        webView.loadUrl(APP_URL);
    }

    private View buildSplash(boolean dark) {
        int bg = dark ? Color.BLACK : Color.WHITE;
        int fg = dark ? Color.WHITE : Color.BLACK;
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(bg);
        layout.setPadding(dp(32), dp(32), dp(32), dp(32));

        TextView mark = new TextView(this);
        mark.setText("LR");
        mark.setTextSize(46);
        mark.setTextColor(fg);
        mark.setGravity(Gravity.CENTER);
        mark.setTypeface(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD);
        layout.addView(mark);

        TextView subtitle = new TextView(this);
        subtitle.setText("智能错题整理");
        subtitle.setTextSize(13);
        subtitle.setTextColor(fg);
        subtitle.setAlpha(0.55f);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        subParams.topMargin = dp(8);
        layout.addView(subtitle, subParams);

        ProgressBar progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        progress.getIndeterminateDrawable().setColorFilter(fg, android.graphics.PorterDuff.Mode.SRC_IN);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(dp(26), dp(26));
        progressParams.topMargin = dp(26);
        layout.addView(progress, progressParams);
        return layout;
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setTextZoom(100);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setUserAgentString(settings.getUserAgentString() + " LRStudyAndroid/1.6");

        CookieManager.getInstance().setAcceptCookie(true);
        try { CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true); } catch (Exception ignored) {}
        webView.addJavascriptInterface(new NativeBridge(this), BRIDGE_NAME);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse response = assetLoader == null ? null
                        : assetLoader.shouldInterceptRequest(request.getUrl());
                return response != null ? response : super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return interceptExternal(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return interceptExternal(Uri.parse(url));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                dismissSplash();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                resetCameraOutput();
                if (params.isCaptureEnabled() && launchCamera()) return true;
                return launchFilePicker(params);
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.deny();
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimeType, long contentLength) {
                if (url == null || url.startsWith("blob:") || url.startsWith("data:")) return;
                try {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    if (mimeType != null && !mimeType.isEmpty()) request.setMimeType(mimeType);
                    if (userAgent != null) request.addRequestHeader("User-Agent", userAgent);
                    request.setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                            "LRStudy/" + name);
                    DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    if (manager == null) throw new IllegalStateException("下载服务不可用");
                    manager.enqueue(request);
                    Toast.makeText(MainActivity.this, "开始下载到「下载/LRStudy」",
                            Toast.LENGTH_LONG).show();
                } catch (Exception error) {
                    Toast.makeText(MainActivity.this, "下载失败：" + error.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private boolean interceptExternal(Uri uri) {
        if (uri == null) return true;
        String scheme = uri.getScheme();
        if (("https".equals(scheme) || "http".equals(scheme))
                && "appassets.androidplatform.net".equals(uri.getHost())) {
            return false;
        }
        if ("http".equals(scheme) || "https".equals(scheme)
                || "mailto".equals(scheme) || "tel".equals(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception error) {
                Toast.makeText(this, "没有可以打开这个链接的应用", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        return false;
    }

    private boolean launchFilePicker(WebChromeClient.FileChooserParams params) {
        boolean multiple = params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE;
        String accept = "";
        String[] acceptTypes = params.getAcceptTypes();
        if (acceptTypes != null) {
            StringBuilder builder = new StringBuilder();
            for (String type : acceptTypes) {
                if (type != null) builder.append(type).append(',');
            }
            accept = builder.toString().toLowerCase(Locale.US);
        }
        String mime = accept.contains("image") ? "image/*" : "*/*";
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        if (multiple) intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        if (accept.contains("image")) {
            intent.putExtra(Intent.EXTRA_MIME_TYPES,
                    new String[]{"image/jpeg", "image/png", "image/webp", "image/gif",
                            "image/heic", "image/heif"});
        } else if (accept.contains("zip")) {
            intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                    "application/zip", "application/x-zip-compressed", "application/octet-stream"});
        }
        try {
            startActivityForResult(intent, REQUEST_FILE);
            return true;
        } catch (ActivityNotFoundException error) {
            try {
                Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                fallback.addCategory(Intent.CATEGORY_OPENABLE);
                fallback.setType(mime);
                if (multiple) fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(fallback, REQUEST_FILE);
                return true;
            } catch (Exception second) {
                filePathCallback = null;
                Toast.makeText(this, "没有可用的文件选择器", Toast.LENGTH_LONG).show();
                return false;
            }
        } catch (Exception error) {
            filePathCallback = null;
            Toast.makeText(this, "无法打开文件选择器", Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private boolean launchCamera() {
        try {
            File dir = new File(getCacheDir(), "lrstudy");
            if (!dir.exists() && !dir.mkdirs()) return false;
            cameraOutputFile = File.createTempFile("capture_", ".jpg", dir);
            cameraOutputUri = FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", cameraOutputFile);
            Intent capture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            capture.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
            capture.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if (capture.resolveActivity(getPackageManager()) == null) {
                resetCameraOutput();
                return false;
            }
            startActivityForResult(capture, REQUEST_CAMERA);
            return true;
        } catch (Exception error) {
            resetCameraOutput();
            return false;
        }
    }

    private void resetCameraOutput() {
        cameraOutputUri = null;
        if (cameraOutputFile != null) {
            try { if (cameraOutputFile.length() == 0) cameraOutputFile.delete(); } catch (Exception ignored) {}
            cameraOutputFile = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_FILE) {
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    List<Uri> uris = new ArrayList<>();
                    if (data.getClipData() != null) {
                        int count = Math.min(20, data.getClipData().getItemCount());
                        for (int i = 0; i < count; i++) {
                            Uri uri = data.getClipData().getItemAt(i).getUri();
                            if (uri != null) uris.add(uri);
                        }
                    } else if (data.getData() != null) {
                        uris.add(data.getData());
                    }
                    if (!uris.isEmpty()) results = uris.toArray(new Uri[0]);
                }
            }
            if (filePathCallback != null) filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else if (requestCode == REQUEST_CAMERA) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && cameraOutputUri != null
                    && cameraOutputFile != null && cameraOutputFile.length() > 0) {
                results = new Uri[]{cameraOutputUri};
            }
            if (filePathCallback != null) filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            cameraOutputUri = null;
            cameraOutputFile = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_STORAGE) {
            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            Toast.makeText(this, granted ? "已允许存储权限，可导出 PDF / ZIP"
                    : "未允许存储权限，PDF / ZIP 将无法保存", Toast.LENGTH_LONG).show();
        }
    }

    void evalJs(String script) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(script, null);
        });
    }

    void applySystemTheme(boolean dark) {
        Window window = getWindow();
        int bg = dark ? Color.BLACK : Color.WHITE;
        int fg = dark ? Color.WHITE : Color.BLACK;
        window.setStatusBarColor(bg);
        // Dark navigation icons are only available from API 26. Keep a black
        // navigation bar on 23–25 so the system icons stay visible.
        window.setNavigationBarColor(Build.VERSION.SDK_INT >= 26 ? bg : Color.BLACK);
        if (Build.VERSION.SDK_INT >= 23) {
            int flags = window.getDecorView().getSystemUiVisibility();
            if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) {
                if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                else flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            window.getDecorView().setSystemUiVisibility(flags);
        }
        if (webView != null) webView.setBackgroundColor(bg);
        View content = findViewById(android.R.id.content);
        if (content != null) content.setBackgroundColor(bg);
        if (splash != null) splash.setBackgroundColor(bg);
        // Keep the splash text legible while the WebView finishes loading.
        if (splash instanceof LinearLayout) {
            LinearLayout layout = (LinearLayout) splash;
            for (int i = 0; i < layout.getChildCount(); i++) {
                View child = layout.getChildAt(i);
                if (child instanceof TextView) ((TextView) child).setTextColor(fg);
            }
        }
    }

    private void dismissSplash() {
        if (splash == null) return;
        final View view = splash;
        splash = null;
        view.animate().alpha(0f).setDuration(220).withEndAction(() -> {
            ViewGroup parent = (ViewGroup) view.getParent();
            if (parent != null) parent.removeView(view);
        }).start();
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript(
                "(function(){try{return window.__lrHandleBack?window.__lrHandleBack():'none';}catch(e){return 'none';}})()",
                value -> {
                    if (value != null && value.contains("modal")) return;
                    if (webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        MainActivity.super.onBackPressed();
                    }
                });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            notifySystemTheme();
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        notifySystemTheme();
    }

    private void notifySystemTheme() {
        if (webView == null) return;
        boolean dark = (getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        webView.evaluateJavascript(
                "window.__onSystemThemeChanged && window.__onSystemThemeChanged(" + dark + ");",
                null);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface(BRIDGE_NAME);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
