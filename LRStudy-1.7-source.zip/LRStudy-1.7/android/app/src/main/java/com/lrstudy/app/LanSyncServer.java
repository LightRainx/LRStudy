package com.lrstudy.app;

import android.util.Base64;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Enumeration;

/** Small one-time HTTP server used by the Android host for LAN sync. */
final class LanSyncServer {
    static final long TTL_MS = 5 * 60 * 1000L;
    private final byte[] zip;
    private final String code;
    private final long expiresAt;
    private ServerSocket server;
    private Thread thread;
    private volatile boolean running;

    LanSyncServer(byte[] zip, String code) {
        this.zip = zip;
        this.code = code == null ? "" : code;
        this.expiresAt = System.currentTimeMillis() + TTL_MS;
    }

    synchronized String start() throws IOException {
        stop();
        server = new ServerSocket();
        server.setReuseAddress(true);
        server.bind(new InetSocketAddress(0));
        server.setSoTimeout(1000);
        running = true;
        String ip = findLanAddress();
        String url = "http://" + ip + ":" + server.getLocalPort();
        thread = new Thread(this::loop, "lrstudy-lan-sync");
        thread.setDaemon(true);
        thread.start();
        return "{\"ok\":true,\"ip\":" + quote(ip)
                + ",\"port\":" + server.getLocalPort()
                + ",\"url\":" + quote(url)
                + ",\"expiresAt\":" + expiresAt + "}";
    }

    synchronized void stop() {
        running = false;
        if (server != null) {
            try { server.close(); } catch (IOException ignored) {}
            server = null;
        }
        if (thread != null) {
            thread.interrupt();
            thread = null;
        }
    }

    boolean isRunning() {
        return running && System.currentTimeMillis() < expiresAt;
    }

    private void loop() {
        while (running && System.currentTimeMillis() < expiresAt) {
            try (Socket client = server.accept()) {
                client.setSoTimeout(5000);
                handle(client);
            } catch (SocketTimeoutException ignored) {
            } catch (Exception ignored) {
                if (!running) break;
            }
        }
        stop();
    }

    private void handle(Socket client) throws IOException {
        InputStream input = new BufferedInputStream(client.getInputStream());
        StringBuilder line = new StringBuilder();
        int previous = -1;
        int value;
        while ((value = input.read()) != -1) {
            if (value == '\n') break;
            if (value != '\r' && line.length() < 4096) line.append((char) value);
            previous = value;
        }
        String request = line.toString();
        String[] parts = request.split(" ");
        if (parts.length < 2) {
            respond(client, 400, "text/plain", "Bad request".getBytes(StandardCharsets.UTF_8), false);
            return;
        }
        String method = parts[0];
        String path = parts[1];
        if ("OPTIONS".equalsIgnoreCase(method)) {
            respond(client, 204, "text/plain", new byte[0], false);
            return;
        }
        if (!"GET".equalsIgnoreCase(method)) {
            respond(client, 405, "text/plain", "Method not allowed".getBytes(StandardCharsets.UTF_8), false);
            return;
        }
        int q = path.indexOf('?');
        String query = q >= 0 ? path.substring(q + 1) : "";
        String route = q >= 0 ? path.substring(0, q) : path;
        if ("/sync".equals(route)) {
            String supplied = queryParam(query, "code");
            if (!code.isEmpty() && !code.equals(supplied)) {
                respond(client, 403, "text/plain", "Invalid code".getBytes(StandardCharsets.UTF_8), false);
                return;
            }
            respond(client, 200, "application/zip", zip, true);
            stop();
            return;
        }
        if ("/".equals(route) || "/info".equals(route)) {
            String body = "{\"ok\":true,\"expiresAt\":" + expiresAt + "}";
            respond(client, 200, "application/json", body.getBytes(StandardCharsets.UTF_8), false);
            return;
        }
        respond(client, 404, "text/plain", "Not found".getBytes(StandardCharsets.UTF_8), false);
    }

    private void respond(Socket client, int status, String contentType, byte[] body, boolean attachment) throws IOException {
        OutputStream output = new BufferedOutputStream(client.getOutputStream());
        String reason = status == 200 ? "OK" : status == 204 ? "No Content" : status == 403 ? "Forbidden" : status == 404 ? "Not Found" : "Error";
        String headers = "HTTP/1.1 " + status + " " + reason + "\r\n"
                + "Content-Type: " + contentType + "\r\n"
                + "Content-Length: " + body.length + "\r\n"
                + "Access-Control-Allow-Origin: *\r\n"
                + "Access-Control-Allow-Methods: GET, OPTIONS\r\n"
                + "Access-Control-Allow-Headers: *\r\n"
                + "Cache-Control: no-store\r\n"
                + (attachment ? "Content-Disposition: attachment; filename=\"LRStudy.zip\"\r\n" : "")
                + "Connection: close\r\n\r\n";
        output.write(headers.getBytes(StandardCharsets.US_ASCII));
        if (body.length > 0) output.write(body);
        output.flush();
        try { output.close(); } catch (IOException ignored) {}
    }

    private static String queryParam(String query, String name) {
        for (String part : query.split("&")) {
            int eq = part.indexOf('=');
            if (eq < 0) continue;
            if (name.equals(part.substring(0, eq))) {
                try {
                    return URLDecoder.decode(part.substring(eq + 1), "UTF-8");
                } catch (Exception ignored) {
                    return part.substring(eq + 1);
                }
            }
        }
        return "";
    }

    private static String quote(String value) {
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    private static String findLanAddress() {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            for (NetworkInterface network : Collections.list(interfaces)) {
                if (!network.isUp() || network.isLoopback()) continue;
                for (InetAddress address : Collections.list(network.getInetAddresses())) {
                    if (address instanceof Inet4Address && !address.isLoopbackAddress() && address.isSiteLocalAddress()) {
                        return address.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {}
        return "127.0.0.1";
    }
}
