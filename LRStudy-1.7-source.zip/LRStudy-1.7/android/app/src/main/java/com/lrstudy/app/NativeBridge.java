package com.lrstudy.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Native capabilities that a browser sandbox cannot provide reliably:
 * saving generated PDF/ZIP files from blob URLs, and mirroring the app theme
 * to the Android system bars.
 */
public final class NativeBridge {
    private static final String DOWNLOAD_FOLDER = "LRStudy";
    private final MainActivity activity;
    private LanSyncServer lanSyncServer;

    NativeBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public String saveBase64(String filename, String mime, String base64) {
        try {
            if (base64 == null || base64.isEmpty()) return "error:文件内容为空";
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            if (bytes.length == 0) return "error:文件内容为空";
            String name = sanitize(filename);
            String type = mime == null ? "" : mime.trim();
            int semicolon = type.indexOf(';');
            if (semicolon >= 0) type = type.substring(0, semicolon).trim();
            if (type.isEmpty()) type = "application/octet-stream";
            if (Build.VERSION.SDK_INT >= 29) {
                String saved = saveWithMediaStore(name, type, bytes);
                return "ok:下载/" + DOWNLOAD_FOLDER + "/" + saved;
            }
            String saved = saveLegacy(name, type, bytes);
            return "ok:下载/" + DOWNLOAD_FOLDER + "/" + saved;
        } catch (SecurityException error) {
            return "error:没有存储权限，请在系统设置中允许后重试";
        } catch (Exception error) {
            String message = error.getMessage();
            if (message == null || message.trim().isEmpty()) message = "未知错误";
            return "error:" + message;
        }
    }

    @JavascriptInterface
    public void toast(String message) {
        if (message == null) return;
        final String text = message.length() > 240 ? message.substring(0, 240) + "…" : message;
        activity.runOnUiThread(() -> Toast.makeText(activity, text, Toast.LENGTH_LONG).show());
    }

    @JavascriptInterface
    public void setTheme(String theme) {
        final boolean dark = "dark".equals(theme);
        activity.runOnUiThread(() -> activity.applySystemTheme(dark));
    }

    @JavascriptInterface
    public boolean getSystemDark() {
        int mode = activity.getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }

    /**
     * Hand a generated PDF to Android's system print dialog. The PDF is kept
     * in cache only long enough for PrintDocumentAdapter to stream it.
     */
    @JavascriptInterface
    public void printPdf(String filename, String base64) {
        try {
            if (base64 == null || base64.isEmpty()) {
                toast("打印文件为空");
                return;
            }
            final byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            final File file = new File(activity.getCacheDir(), sanitize(filename == null ? "LRStudy.pdf" : filename));
            try (FileOutputStream output = new FileOutputStream(file)) {
                output.write(bytes);
            }
            final int pages;
            try (ParcelFileDescriptor pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
                 PdfRenderer renderer = new PdfRenderer(pfd)) {
                pages = Math.max(1, renderer.getPageCount());
            }
            activity.runOnUiThread(() -> {
                try {
                    PrintManager manager = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                    if (manager == null) {
                        toast("系统打印服务不可用");
                        file.delete();
                        return;
                    }
                    PrintDocumentAdapter adapter = new PrintDocumentAdapter() {
                        @Override
                        public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                                             CancellationSignal cancellationSignal, LayoutResultCallback callback,
                                             Bundle extras) {
                            if (cancellationSignal.isCanceled()) {
                                callback.onLayoutCancelled();
                                return;
                            }
                            PrintDocumentInfo info = new PrintDocumentInfo.Builder(sanitize(filename == null ? "LRStudy.pdf" : filename))
                                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                                    .setPageCount(pages)
                                    .build();
                            callback.onLayoutFinished(info, true);
                        }

                        @Override
                        public void onWrite(PageRange[] pagesRequested, ParcelFileDescriptor destination,
                                            CancellationSignal cancellationSignal, WriteResultCallback callback) {
                            try (InputStream input = new FileInputStream(file);
                                 OutputStream output = new FileOutputStream(destination.getFileDescriptor())) {
                                byte[] buffer = new byte[8192];
                                int read;
                                while ((read = input.read(buffer)) != -1) {
                                    if (cancellationSignal.isCanceled()) {
                                        callback.onWriteCancelled();
                                        return;
                                    }
                                    output.write(buffer, 0, read);
                                }
                                output.flush();
                                callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                            } catch (Exception error) {
                                callback.onWriteFailed(error.getMessage());
                            }
                        }

                        @Override
                        public void onFinish() {
                            file.delete();
                        }
                    };
                    PrintAttributes attributes = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                    manager.print("LRStudy 练习卷", adapter, attributes);
                } catch (Exception error) {
                    file.delete();
                    toast("无法打开打印窗口：" + error.getMessage());
                }
            });
        } catch (Exception error) {
            toast("无法准备打印：" + (error.getMessage() == null ? "未知错误" : error.getMessage()));
        }
    }

    /**
     * WebDAV transport that bypasses browser CORS. Runs on a background thread
     * and streams the response back to JS in small Base64 chunks.
     */
    @JavascriptInterface
    public void davRequest(final String requestId, final String method, final String url,
                           final String headersJson, final String bodyBase64, final int timeoutMs) {
        new Thread(() -> {
            try {
                java.net.URL target = new java.net.URL(url);
                String scheme = target.getProtocol().toLowerCase(java.util.Locale.US);
                if (!"http".equals(scheme) && !"https".equals(scheme)) {
                    throw new IllegalArgumentException("WebDAV 地址必须使用 http 或 https");
                }
                int timeout = Math.max(5000, Math.min(timeoutMs > 0 ? timeoutMs : 90000, 240000));
                OkHttpClient client = new OkHttpClient.Builder()
                        .connectTimeout(timeout, TimeUnit.MILLISECONDS)
                        .readTimeout(timeout, TimeUnit.MILLISECONDS)
                        .writeTimeout(timeout, TimeUnit.MILLISECONDS)
                        .followRedirects(false)
                        .build();

                String contentType = null;
                Request.Builder builder = new Request.Builder().url(url);
                try {
                    JSONObject headers = new JSONObject(headersJson == null ? "{}" : headersJson);
                    Iterator<String> keys = headers.keys();
                    while (keys.hasNext()) {
                        String key = keys.next();
                        if (key == null) continue;
                        String lower = key.toLowerCase(java.util.Locale.US);
                        if ("host".equals(lower) || "content-length".equals(lower)
                                || "connection".equals(lower)) continue;
                        String value = headers.optString(key, null);
                        if (value == null) continue;
                        if ("content-type".equals(lower)) contentType = value;
                        builder.addHeader(key, value);
                    }
                } catch (Exception ignored) {
                    // Malformed optional headers should not abort the request.
                }

                byte[] bodyBytes = (bodyBase64 == null || bodyBase64.isEmpty())
                        ? null : Base64.decode(bodyBase64, Base64.DEFAULT);
                RequestBody body = null;
                if (bodyBytes != null && bodyBytes.length > 0) {
                    MediaType mediaType = MediaType.parse(
                            contentType == null || contentType.trim().isEmpty()
                                    ? "application/octet-stream" : contentType);
                    body = RequestBody.create(mediaType, bodyBytes);
                }
                String requestMethod = method == null || method.trim().isEmpty()
                        ? "GET" : method.toUpperCase(java.util.Locale.US);
                builder.method(requestMethod, body);

                int status;
                byte[] responseBytes;
                String responseType;
                try (Response response = client.newCall(builder.build()).execute()) {
                    status = response.code();
                    responseType = response.header("Content-Type");
                    responseBytes = response.body() == null ? new byte[0] : response.body().bytes();
                    if (responseBytes.length > 120 * 1024 * 1024) {
                        throw new IllegalStateException("WebDAV 响应超过 120MB");
                    }
                }

                activity.evalJs("window.__lrNativeDavStart&&window.__lrNativeDavStart("
                        + JSONObject.quote(requestId) + "," + status + ","
                        + JSONObject.quote(responseType == null ? "" : responseType) + ");");
                final int chunkSize = 128 * 1024;
                for (int offset = 0; offset < responseBytes.length; offset += chunkSize) {
                    int length = Math.min(chunkSize, responseBytes.length - offset);
                    byte[] part = new byte[length];
                    System.arraycopy(responseBytes, offset, part, 0, length);
                    String encoded = Base64.encodeToString(part, Base64.NO_WRAP);
                    activity.evalJs("window.__lrNativeDavChunk&&window.__lrNativeDavChunk("
                            + JSONObject.quote(requestId) + "," + JSONObject.quote(encoded) + ");");
                }
                activity.evalJs("window.__lrNativeDavDone&&window.__lrNativeDavDone("
                        + JSONObject.quote(requestId) + ");");
            } catch (Exception error) {
                String message = error.getMessage();
                if (message == null || message.trim().isEmpty()) message = "WebDAV 请求失败";
                activity.evalJs("window.__lrNativeDavFail&&window.__lrNativeDavFail("
                        + JSONObject.quote(requestId) + "," + JSONObject.quote(message) + ");");
            }
        }, "lrstudy-webdav").start();
    }

    @JavascriptInterface
    public String startLanSync(String zipBase64, String code) {
        try {
            if (zipBase64 == null || zipBase64.isEmpty()) {
                return "{\"ok\":false,\"error\":\"同步数据为空\"}";
            }
            byte[] bytes = Base64.decode(zipBase64, Base64.DEFAULT);
            if (lanSyncServer != null) lanSyncServer.stop();
            lanSyncServer = new LanSyncServer(bytes, code);
            return lanSyncServer.start();
        } catch (Exception error) {
            if (lanSyncServer != null) lanSyncServer.stop();
            lanSyncServer = null;
            return "{\"ok\":false,\"error\":" + JSONObject.quote(error.getMessage() == null ? "内网同步启动失败" : error.getMessage()) + "}";
        }
    }

    @JavascriptInterface
    public String stopLanSync() {
        if (lanSyncServer != null) {
            lanSyncServer.stop();
            lanSyncServer = null;
        }
        return "{\"ok\":true}";
    }

    private String saveWithMediaStore(String name, String mime, byte[] bytes) throws Exception {
        ContentResolver resolver = activity.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + File.separator + DOWNLOAD_FOLDER);
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);

        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("无法创建下载文件");

        boolean written = false;
        try (OutputStream output = resolver.openOutputStream(uri)) {
            if (output == null) throw new IllegalStateException("无法写入下载文件");
            output.write(bytes);
            output.flush();
            written = true;
        } finally {
            if (!written) {
                try { resolver.delete(uri, null, null); } catch (Exception ignored) {}
            }
        }

        ContentValues done = new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
        resolver.update(uri, done, null, null);

        String actual = name;
        try (Cursor cursor = resolver.query(uri,
                new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                String queried = cursor.getString(0);
                if (queried != null && !queried.isEmpty()) actual = queried;
            }
        }
        return actual;
    }

    private String saveLegacy(String name, String mime, byte[] bytes) throws Exception {
        if (activity.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            activity.runOnUiThread(() -> activity.requestPermissions(
                    new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, MainActivity.REQUEST_STORAGE));
            throw new SecurityException("需要存储权限");
        }
        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File folder = new File(downloads, DOWNLOAD_FOLDER);
        if (!folder.exists() && !folder.mkdirs()) {
            throw new IllegalStateException("无法创建下载目录");
        }
        File target = uniqueFile(folder, name);
        try (FileOutputStream output = new FileOutputStream(target)) {
            output.write(bytes);
            output.flush();
        }
        MediaScannerConnection.scanFile(activity, new String[]{target.getAbsolutePath()},
                new String[]{mime}, null);
        return target.getName();
    }

    private static File uniqueFile(File folder, String name) {
        File candidate = new File(folder, name);
        if (!candidate.exists()) return candidate;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String extension = dot > 0 ? name.substring(dot) : "";
        for (int index = 1; index < 500; index++) {
            candidate = new File(folder, base + "-" + index + extension);
            if (!candidate.exists()) return candidate;
        }
        return new File(folder, base + "-" + System.currentTimeMillis() + extension);
    }

    static String sanitize(String filename) {
        String name = filename == null ? "" : filename;
        int slash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
        if (slash >= 0) name = name.substring(slash + 1);
        name = name.replaceAll("[\\p{Cntrl}:*?\"<>|]", "").trim();
        if (name.isEmpty() || ".".equals(name) || "..".equals(name)) name = "LRStudy-download.bin";
        if (name.length() > 120) {
            int dot = name.lastIndexOf('.');
            String extension = dot > 0 && name.length() - dot <= 10 ? name.substring(dot) : "";
            name = name.substring(0, 120 - extension.length()) + extension;
        }
        return name;
    }
}
