/* LRStudy v1.7 — shared utilities, ZIP reader/writer, image conversion */
(function () {
  'use strict';

  const LR = (window.LR = window.LR || {});

  LR.APP_NAME = 'LRStudy';
  LR.APP_VERSION = 'v1.7';

  LR.GRADE_LEVELS = [
    { value: 'primary_1', label: '小学一年级' },
    { value: 'primary_2', label: '小学二年级' },
    { value: 'primary_3', label: '小学三年级' },
    { value: 'primary_4', label: '小学四年级' },
    { value: 'primary_5', label: '小学五年级' },
    { value: 'primary_6', label: '小学六年级' },
    { value: 'junior_1', label: '初中一年级' },
    { value: 'junior_2', label: '初中二年级' },
    { value: 'junior_3', label: '初中三年级' },
    { value: 'senior_1', label: '高中一年级' },
    { value: 'senior_2', label: '高中二年级' },
    { value: 'senior_3', label: '高中三年级' }
  ];

  LR.gradeLabel = function (value) {
    const hit = LR.GRADE_LEVELS.find(function (item) { return item.value === value; });
    return hit ? hit.label : '';
  };
  LR.BACKUP_FILENAME = 'LRStudy.zip';

  LR.uid = function (prefix) {
    const p = prefix || 'id';
    try {
      if (window.crypto && crypto.randomUUID) return p + '-' + crypto.randomUUID();
    } catch (_) {}
    return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  };

  LR.escapeHTML = function (value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  };

  LR.escapeAttr = LR.escapeHTML;

  LR.textToHTML = function (value) {
    return LR.escapeHTML(value).replace(/\n/g, '<br>');
  };

  LR.clamp = function (n, min, max) {
    return Math.min(max, Math.max(min, Number(n) || 0));
  };

  LR.sleep = function (ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  };

  LR.clone = function (obj) {
    if (obj == null) return obj;
    try { return structuredClone(obj); } catch (_) { return JSON.parse(JSON.stringify(obj)); }
  };

  LR.pad = function (n) { return String(n).padStart(2, '0'); };

  LR.formatDate = function (input, withTime) {
    if (!input) return '—';
    const d = input instanceof Date ? input : new Date(input);
    if (isNaN(d.getTime())) return '—';
    const base = d.getFullYear() + '.' + LR.pad(d.getMonth() + 1) + '.' + LR.pad(d.getDate());
    return withTime ? base + ' ' + LR.pad(d.getHours()) + ':' + LR.pad(d.getMinutes()) : base;
  };

  LR.relativeDate = function (input) {
    if (!input) return '—';
    const d = new Date(input);
    const diff = Date.now() - d.getTime();
    if (isNaN(diff)) return '—';
    if (diff < 60 * 1000) return '刚刚';
    if (diff < 60 * 60 * 1000) return Math.floor(diff / 60000) + ' 分钟前';
    if (diff < 24 * 60 * 60 * 1000) return Math.floor(diff / 3600000) + ' 小时前';
    if (diff < 7 * 24 * 60 * 60 * 1000) return Math.floor(diff / 86400000) + ' 天前';
    return LR.formatDate(d);
  };

  LR.fileSize = function (bytes) {
    const n = Number(bytes) || 0;
    if (n < 1024) return n + ' B';
    if (n < 1024 * 1024) return (n / 1024).toFixed(0) + ' KB';
    return (n / 1024 / 1024).toFixed(1) + ' MB';
  };

  LR.debounce = function (fn, wait) {
    let timer = null;
    return function () {
      const args = arguments;
      const ctx = this;
      clearTimeout(timer);
      timer = setTimeout(function () { fn.apply(ctx, args); }, wait);
    };
  };

  LR.safeFilename = function (value) {
    return String(value || 'LRStudy')
      .replace(/[\\/:*?"<>|\n\r]+/g, '-')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 80) || 'LRStudy';
  };

  LR.downloadBlob = async function (blob, filename) {
    const safeName = filename || LR.BACKUP_FILENAME;
    // Android WebView cannot download blob: anchors. Hand the bytes to the
    // native DownloadBridge when the app is running inside the APK.
    if (window.LRNative && typeof window.LRNative.saveBase64 === 'function') {
      const dataURL = await LR.readBlobAsDataURL(blob);
      const base64 = String(dataURL).slice(String(dataURL).indexOf(',') + 1);
      let result;
      try {
        result = window.LRNative.saveBase64(safeName, blob.type || 'application/octet-stream', base64);
      } catch (err) {
        throw new Error('保存文件失败：' + (err && err.message ? err.message : '原生下载通道不可用'));
      }
      if (typeof result === 'string' && result.indexOf('ok:') === 0) {
        if (window.LRNative.toast) {
          try { window.LRNative.toast('已保存到 ' + result.slice(3)); } catch (_) {}
        }
        return result;
      }
      throw new Error(typeof result === 'string' ? result.replace(/^error:/, '') : '保存文件失败');
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = safeName;
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () {
      a.remove();
      URL.revokeObjectURL(url);
    }, 2500);
    return safeName;
  };

  LR.readBlobAsDataURL = function (blob) {
    return new Promise(function (resolve, reject) {
      const reader = new FileReader();
      reader.onload = function () { resolve(String(reader.result || '')); };
      reader.onerror = function () { reject(reader.error || new Error('读取文件失败')); };
      reader.readAsDataURL(blob);
    });
  };

  LR.dataURLToBlob = function (dataURL) {
    const parts = String(dataURL).split(',');
    const meta = parts[0] || '';
    const mimeMatch = meta.match(/data:([^;]+)/);
    const mime = mimeMatch ? mimeMatch[1] : 'application/octet-stream';
    const binary = atob(parts.slice(1).join(','));
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return new Blob([bytes], { type: mime });
  };

  LR.loadImageElement = function (source) {
    return new Promise(function (resolve, reject) {
      const img = new Image();
      img.onload = function () { resolve(img); };
      img.onerror = function () { reject(new Error('图片加载失败，请更换图片重试')); };
      img.decoding = 'async';
      if (source instanceof Blob) {
        const url = URL.createObjectURL(source);
        img.onload = function () {
          URL.revokeObjectURL(url);
          resolve(img);
        };
        img.onerror = function () {
          URL.revokeObjectURL(url);
          reject(new Error('图片加载失败，请更换图片重试'));
        };
        img.src = url;
      } else {
        img.src = String(source);
      }
    });
  };

  LR.imageFileToCanvas = function (file, maxSide) {
    return LR.loadImageElement(file).then(function (img) {
      let w = img.naturalWidth || img.width;
      let h = img.naturalHeight || img.height;
      if (!w || !h) throw new Error('无法读取图片尺寸');
      const limit = maxSide || 2400;
      const scale = Math.min(1, limit / Math.max(w, h));
      w = Math.max(1, Math.round(w * scale));
      h = Math.max(1, Math.round(h * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, w, h);
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, 0, 0, w, h);
      return canvas;
    });
  };

  LR.canvasToBlob = function (canvas, mime, quality) {
    return new Promise(function (resolve, reject) {
      canvas.toBlob(function (blob) {
        if (blob) resolve(blob);
        else reject(new Error('图片导出失败'));
      }, mime || 'image/jpeg', quality == null ? 0.86 : quality);
    });
  };

  LR.canvasToDataURL = function (canvas, mime, quality) {
    return canvas.toDataURL(mime || 'image/jpeg', quality == null ? 0.86 : quality);
  };

  LR.dataURLSize = function (dataURL) {
    if (!dataURL) return 0;
    const idx = String(dataURL).indexOf(',');
    if (idx < 0) return String(dataURL).length;
    return Math.ceil((String(dataURL).length - idx - 1) * 0.75);
  };

  /* ------------------------------------------------------------------ */
  /* ZIP (store + optional deflate reading)                              */
  /* ------------------------------------------------------------------ */

  const CRC_TABLE = (function () {
    const table = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      table[n] = c >>> 0;
    }
    return table;
  })();

  LR.crc32 = function (bytes) {
    let c = 0xFFFFFFFF;
    for (let i = 0; i < bytes.length; i++) {
      c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
    }
    return (c ^ 0xFFFFFFFF) >>> 0;
  };

  function encodeUTF8(str) {
    return new TextEncoder().encode(String(str));
  }

  function dosDateTime(date) {
    const d = date || new Date();
    const year = Math.max(1980, d.getFullYear());
    const time = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2);
    const day = ((year - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    return { time: time & 0xFFFF, date: day & 0xFFFF };
  }

  function toBytes(data) {
    if (data instanceof Uint8Array) return Promise.resolve(data);
    if (data instanceof ArrayBuffer) return Promise.resolve(new Uint8Array(data));
    if (data instanceof Blob) return data.arrayBuffer().then(function (buf) { return new Uint8Array(buf); });
    return Promise.resolve(encodeUTF8(data == null ? '' : String(data)));
  }

  function header(size) {
    return new Uint8Array(size);
  }

  function writeU16(arr, offset, value) {
    arr[offset] = value & 0xFF;
    arr[offset + 1] = (value >>> 8) & 0xFF;
  }

  function writeU32(arr, offset, value) {
    arr[offset] = value & 0xFF;
    arr[offset + 1] = (value >>> 8) & 0xFF;
    arr[offset + 2] = (value >>> 16) & 0xFF;
    arr[offset + 3] = (value >>> 24) & 0xFF;
  }

  function readU16(arr, offset) {
    return arr[offset] | (arr[offset + 1] << 8);
  }

  function readU32(arr, offset) {
    return (arr[offset] | (arr[offset + 1] << 8) | (arr[offset + 2] << 16) | (arr[offset + 3] << 24)) >>> 0;
  }

  /**
   * Build a ZIP Blob. entries: [{ name, data: Blob|Uint8Array|string }]
   * Uses STORE (uncompressed) for maximum compatibility with images.
   */
  LR.zipCreate = async function (entries) {
    if (!Array.isArray(entries) || !entries.length) throw new Error('没有可打包的文件');
    const prepared = [];
    let offset = 0;
    const dt = dosDateTime(new Date());
    const localParts = [];
    const centralParts = [];

    for (const entry of entries) {
      const nameBytes = encodeUTF8(entry.name);
      const data = await toBytes(entry.data);
      const crc = LR.crc32(data);
      if (offset + data.length > 0xFFFFFFFF) throw new Error('备份文件超过 4GB，暂不支持');

      const local = header(30 + nameBytes.length);
      writeU32(local, 0, 0x04034B50);
      writeU16(local, 4, 20);
      writeU16(local, 6, 0x0800);
      writeU16(local, 8, 0); // store
      writeU16(local, 10, dt.time);
      writeU16(local, 12, dt.date);
      writeU32(local, 14, crc);
      writeU32(local, 18, data.length);
      writeU32(local, 22, data.length);
      writeU16(local, 26, nameBytes.length);
      writeU16(local, 28, 0);
      local.set(nameBytes, 30);
      localParts.push(local, data);

      prepared.push({ nameBytes: nameBytes, crc: crc, size: data.length, offset: offset });
      offset += local.length + data.length;
    }

    let centralOffset = offset;
    for (const item of prepared) {
      const central = header(46 + item.nameBytes.length);
      writeU32(central, 0, 0x02014B50);
      writeU16(central, 4, 20);
      writeU16(central, 6, 20);
      writeU16(central, 8, 0x0800);
      writeU16(central, 10, 0);
      writeU16(central, 12, dt.time);
      writeU16(central, 14, dt.date);
      writeU32(central, 16, item.crc);
      writeU32(central, 20, item.size);
      writeU32(central, 24, item.size);
      writeU16(central, 28, item.nameBytes.length);
      writeU16(central, 30, 0);
      writeU16(central, 32, 0);
      writeU16(central, 34, 0);
      writeU16(central, 36, 0);
      writeU32(central, 38, 0);
      writeU32(central, 42, item.offset);
      central.set(item.nameBytes, 46);
      centralParts.push(central);
    }

    const centralSize = centralParts.reduce(function (sum, part) { return sum + part.length; }, 0);
    const end = header(22);
    writeU32(end, 0, 0x06054B50);
    writeU16(end, 4, 0);
    writeU16(end, 6, 0);
    writeU16(end, 8, prepared.length);
    writeU16(end, 10, prepared.length);
    writeU32(end, 12, centralSize);
    writeU32(end, 16, centralOffset);
    writeU16(end, 20, 0);

    return new Blob(localParts.concat(centralParts, [end]), { type: 'application/zip' });
  };

  function inflateRaw(bytes) {
    if (typeof DecompressionStream === 'undefined') {
      return Promise.reject(new Error('当前浏览器不支持解压该 ZIP 备份，请升级浏览器'));
    }
    try {
      const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
      return new Response(stream).arrayBuffer().then(function (buf) { return new Uint8Array(buf); });
    } catch (err) {
      return Promise.reject(new Error('压缩备份解压失败：' + err.message));
    }
  }

  /**
   * Parse a ZIP made by LRStudy (or other STORE/DEFLATE zips).
   * Returns { files: {name: Uint8Array}, order: [names] }.
   */
  LR.zipRead = async function (arrayBuffer) {
    const bytes = new Uint8Array(arrayBuffer);
    if (bytes.length < 22) throw new Error('不是有效的 ZIP 文件');
    let eocd = -1;
    const min = Math.max(0, bytes.length - 65557);
    for (let i = bytes.length - 22; i >= min; i--) {
      if (readU32(bytes, i) === 0x06054B50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('未找到 ZIP 目录，文件可能已损坏');
    const count = readU16(bytes, eocd + 10);
    const centralOffset = readU32(bytes, eocd + 16);
    if (!count) throw new Error('ZIP 备份为空');

    const files = {};
    const order = [];
    let pos = centralOffset;
    for (let i = 0; i < count; i++) {
      if (readU32(bytes, pos) !== 0x02014B50) throw new Error('ZIP 目录结构损坏');
      const method = readU16(bytes, pos + 10);
      const compSize = readU32(bytes, pos + 20);
      const nameLen = readU16(bytes, pos + 28);
      const extraLen = readU16(bytes, pos + 30);
      const commentLen = readU16(bytes, pos + 32);
      const localOffset = readU32(bytes, pos + 42);
      const name = new TextDecoder('utf-8').decode(bytes.subarray(pos + 46, pos + 46 + nameLen));
      pos += 46 + nameLen + extraLen + commentLen;

      if (readU32(bytes, localOffset) !== 0x04034B50) throw new Error('ZIP 文件头损坏：' + name);
      const localNameLen = readU16(bytes, localOffset + 26);
      const localExtraLen = readU16(bytes, localOffset + 28);
      const dataStart = localOffset + 30 + localNameLen + localExtraLen;
      const compressed = bytes.subarray(dataStart, dataStart + compSize);
      let content;
      if (method === 0) content = compressed;
      else if (method === 8) content = await inflateRaw(compressed);
      else throw new Error('不支持 ZIP 压缩方式（' + method + '）：' + name);
      files[name] = content;
      order.push(name);
    }
    return { files: files, order: order };
  };

  /* Small helpers that need DOM but are shared across modules */
  LR.copyText = async function (text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (_) {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        const ok = document.execCommand('copy');
        ta.remove();
        return ok;
      } catch (__) { return false; }
    }
  };

  LR.base64Basic = function (username, password) {
    const bytes = new TextEncoder().encode(String(username) + ':' + String(password));
    let binary = '';
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };
})();
