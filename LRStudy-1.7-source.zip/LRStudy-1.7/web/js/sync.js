/* LRStudy v1.7 — LAN and public (WebRTC) synchronization */
(function () {
  'use strict';

  const LR = window.LR;
  const DEFAULT_PUBLIC_BASE = '';
  const TTL_MS = 5 * 60 * 1000;
  let lanSession = null;
  let lanTimer = null;
  let publicSession = null;
  let publicTimer = null;

  function randomCode() {
    return String(Math.floor(100000 + Math.random() * 900000));
  }

  function bytesToBase64Url(bytes) {
    let binary = '';
    for (let i = 0; i < bytes.length; i += 0x8000) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    }
    return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  function base64UrlToBytes(text) {
    const normalized = String(text || '').replace(/-/g, '+').replace(/_/g, '/');
    const padded = normalized + '='.repeat((4 - normalized.length % 4) % 4);
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  async function importKey(keyText) {
    if (!window.crypto || !window.crypto.subtle) throw new Error('当前环境不支持 Web Crypto 加密');
    return window.crypto.subtle.importKey('raw', base64UrlToBytes(keyText), { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
  }

  const AAD = new TextEncoder().encode('LRStudy-Public-Sync-v1');

  async function encryptBlob(blob, keyText) {
    const key = await importKey(keyText);
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const plain = await blob.arrayBuffer();
    const cipher = await window.crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv, additionalData: AAD }, key, plain);
    return new Blob([iv, cipher], { type: 'application/octet-stream' });
  }

  async function decryptBytes(cipherBytes, keyText) {
    if (cipherBytes.length <= 12) throw new Error('加密同步数据不完整');
    const iv = cipherBytes.subarray(0, 12);
    const data = cipherBytes.subarray(12);
    const key = await importKey(keyText);
    const plain = await window.crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv, additionalData: AAD }, key, data);
    return new Blob([plain], { type: 'application/zip' });
  }

  function isNativeHost() {
    return !!(window.LRNative && typeof window.LRNative.startLanSync === 'function');
  }

  async function snapshot() {
    await LR.db.flush();
    const result = await LR.backup.buildBackup({ includeSecrets: false });
    return result.blob;
  }

  function blobToBase64(blob) {
    return LR.readBlobAsDataURL(blob).then(function (url) {
      return String(url).slice(String(url).indexOf(',') + 1);
    });
  }

  async function restoreSnapshot(blob) {
    const result = await LR.backup.restoreBackup(blob);
    App.applyTheme();
    App.ui.notebookFilter = 'all';
    App.render();
    return result;
  }

  function normalizeLanAddress(address) {
    let base = String(address || '').trim();
    if (!base) throw new Error('请填写主机地址，例如 192.168.1.20:8765');
    if (!/^https?:\/\//i.test(base)) base = 'http://' + base;
    base = base.replace(/\/+$/, '');
    try {
      const url = new URL(base);
      if (!url.port) throw new Error('地址需要带端口，例如 192.168.1.20:8765');
      return url.origin;
    } catch (err) {
      throw new Error('地址格式不对，请填写完整的主机地址和端口');
    }
  }

  async function startLanHost() {
    if (!isNativeHost()) throw new Error('内网同步主机仅支持 Android APK');
    stopLanHost();
    const blob = await snapshot();
    const code = randomCode();
    const result = JSON.parse(window.LRNative.startLanSync(await blobToBase64(blob), code));
    if (!result.ok) throw new Error(result.error || '内网同步启动失败');
    lanSession = {
      code: code,
      ip: result.ip,
      port: result.port,
      url: result.url,
      expiresAt: Math.min(result.expiresAt || (Date.now() + TTL_MS), Date.now() + TTL_MS),
      size: blob.size
    };
    lanTimer = setTimeout(function () { stopLanHost(); }, TTL_MS);
    return lanSession;
  }

  function stopLanHost() {
    if (lanTimer) { clearTimeout(lanTimer); lanTimer = null; }
    if (isNativeHost()) {
      try { window.LRNative.stopLanSync(); } catch (_) {}
    }
    lanSession = null;
  }

  async function joinLan(address, code) {
    const base = normalizeLanAddress(address);
    if (!/^\d{6}$/.test(String(code || '').trim())) throw new Error('请输入 6 位数字配对码');
    const controller = new AbortController();
    const timer = setTimeout(function () { controller.abort(); }, 30000);
    let response;
    try {
      response = await fetch(base + '/sync?code=' + encodeURIComponent(String(code).trim()), {
        method: 'GET',
        cache: 'no-store',
        signal: controller.signal
      });
    } catch (err) {
      clearTimeout(timer);
      throw new Error('连接主机失败：请确认在同一局域网、地址端口正确，且主机已开启内网同步。');
    }
    clearTimeout(timer);
    if (response.status === 403) throw new Error('配对码错误');
    if (!response.ok) throw new Error('主机返回 HTTP ' + response.status);
    const blob = await response.blob();
    if (!blob.size) throw new Error('主机返回的数据为空');
    return blob;
  }

  function ensurePeer() {
    if (!window.LRPeer) throw new Error('WebRTC 模块未加载');
    return new window.LRPeer();
  }

  function waitPeerOpen(peer, timeoutMs) {
    return new Promise(function (resolve, reject) {
      const timer = setTimeout(function () { reject(new Error('连接公网信令超时，请重试')); }, timeoutMs || 20000);
      peer.once('open', function (id) { clearTimeout(timer); resolve(id); });
      peer.once('error', function (err) { clearTimeout(timer); reject(new Error(err && err.message ? err.message : 'WebRTC 信令失败')); });
    });
  }

  function assignPublicLink(peerId, code, key, baseUrl) {
    let base = String(baseUrl || '').trim();
    if (!base) throw new Error('请先填写公网同步入口（已部署的 v1.7 页面地址）');
    if (!/^https?:\/\//i.test(base)) throw new Error('公网同步入口需要以 https:// 开头');
    const hash = '#sync=' + encodeURIComponent(peerId) + '&key=' + encodeURIComponent(key) + '&code=' + encodeURIComponent(code);
    return base.replace(/#.*$/, '').replace(/\/?$/, '/') + hash;
  }

  async function startPublicHost(baseUrl) {
    if (!isNativeHost()) throw new Error('公网同步主机仅支持 Android APK；iOS 可作为接收端');
    if (!String(baseUrl || '').trim()) throw new Error('请先填写公网同步入口（已部署的 v1.7 页面地址）');
    stopPublicHost();
    const blob = await snapshot();
    const key = bytesToBase64Url(window.crypto.getRandomValues(new Uint8Array(32)));
    const code = randomCode();
    const encrypted = await encryptBlob(blob, key);
    const peer = ensurePeer();
    const peerId = await waitPeerOpen(peer, 20000);
    const link = assignPublicLink(peerId, code, key, baseUrl);
    const session = {
      peer: peer,
      code: code,
      key: key,
      link: link,
      size: blob.size,
      encryptedSize: encrypted.size,
      expiresAt: Date.now() + TTL_MS
    };
    peer.on('connection', function (conn) {
      conn.on('data', async function (message) {
        if (!message || message.type !== 'ready') return;
        if (String(message.code) !== code) {
          try { conn.send({ type: 'error', message: '配对码错误' }); conn.close(); } catch (_) {}
          return;
        }
        try {
          const buffer = await encrypted.arrayBuffer();
          conn.send({ type: 'start', size: buffer.byteLength, name: 'LRStudy.zip' });
          const chunkSize = 64 * 1024;
          for (let offset = 0; offset < buffer.byteLength; offset += chunkSize) {
            const channel = conn.dataChannel;
            while (channel && channel.bufferedAmount > 2 * 1024 * 1024) {
              await new Promise(function (resolve) { setTimeout(resolve, 30); });
            }
            conn.send(buffer.slice(offset, offset + chunkSize));
          }
          conn.send({ type: 'end' });
          // The link is one-time: after the encrypted snapshot is sent, stop
          // accepting more guests and close the PeerJS session.
          setTimeout(function () { stopPublicHost(); }, 1500);
        } catch (err) {
          try { conn.send({ type: 'error', message: '发送失败：' + err.message }); } catch (_) {}
        }
      });
    });
    peer.on('error', function (err) {
      if (publicSession === session) {
        // Keep the session object so the UI can show a useful error; the caller
        // may also close it manually.
        console.warn('PeerJS public sync error', err);
      }
    });
    publicSession = session;
    publicTimer = setTimeout(function () { stopPublicHost(); }, TTL_MS);
    return {
      code: code,
      link: link,
      key: key,
      expiresAt: session.expiresAt,
      size: blob.size,
      encryptedSize: encrypted.size
    };
  }

  function stopPublicHost() {
    if (publicTimer) { clearTimeout(publicTimer); publicTimer = null; }
    if (publicSession && publicSession.peer) {
      try { publicSession.peer.destroy(); } catch (_) {}
    }
    publicSession = null;
  }

  function parsePublicInvite(raw) {
    const text = String(raw || '').trim();
    if (!text) throw new Error('请粘贴公网同步链接');
    let url;
    try { url = new URL(text, location.href); } catch (_) { throw new Error('链接格式不对'); }
    const params = new URLSearchParams(url.hash.replace(/^#/, ''));
    const hostId = params.get('sync');
    const key = params.get('key');
    const code = params.get('code');
    if (!hostId || !key) throw new Error('链接缺少同步 ID 或加密密钥');
    return { hostId: hostId, key: key, code: code || '', link: text };
  }

  function getInviteFromUrl() {
    try {
      const params = new URLSearchParams(location.hash.replace(/^#/, ''));
      const hostId = params.get('sync');
      const key = params.get('key');
      if (!hostId || !key) return null;
      return { hostId: hostId, key: key, code: params.get('code') || '', link: location.href };
    } catch (_) {
      return null;
    }
  }

  function consumeInvite() {
    try {
      if (!window.sessionStorage) return null;
      const raw = sessionStorage.getItem('lr-public-invite');
      sessionStorage.removeItem('lr-public-invite');
      if (!raw) return null;
      return JSON.parse(raw);
    } catch (_) {
      return null;
    }
  }

  function joinPublic(raw, onProgress) {
    const invite = typeof raw === 'string' ? parsePublicInvite(raw) : raw;
    if (!invite || !invite.hostId || !invite.key) return Promise.reject(new Error('公网同步链接无效'));
    return new Promise(function (resolve, reject) {
      let peer;
      let conn;
      let chunks = [];
      let total = 0;
      let expected = 0;
      let settled = false;
      const timer = setTimeout(function () { finish(new Error('公网同步超时（5 分钟）')); }, TTL_MS);
      function finish(err, value) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        try { if (conn) conn.close(); } catch (_) {}
        try { if (peer) peer.destroy(); } catch (_) {}
        if (err) reject(err); else resolve(value);
      }
      try {
        peer = ensurePeer();
        peer.on('error', function (err) { finish(new Error('WebRTC 连接失败：' + (err && err.message ? err.message : '请重试'))); });
        peer.on('open', function () {
          conn = peer.connect(invite.hostId, { reliable: true });
          conn.on('open', async function () {
            const ok = await App.confirm({
              title: '接收公网同步？',
              message: '将用主机数据覆盖本机全部错题、图片、解析和练习记录。API Key 与 WebDAV 密码不会同步。',
              hint: '此链接包含端到端加密密钥；接收完成后链接会失效。',
              confirmLabel: '接收并覆盖',
              danger: true
            });
            if (!ok) { finish(new Error('已取消')); return; }
            conn.send({ type: 'ready', code: invite.code || '' });
          });
          conn.on('data', async function (message) {
            if (!message) return;
            if (message.type === 'error') { finish(new Error(message.message || '主机同步失败')); return; }
            if (message.type === 'start') {
              expected = Number(message.size) || 0;
              chunks = [];
              total = 0;
              if (onProgress) onProgress({ phase: 'receiving', received: 0, total: expected });
              return;
            }
            if (message.type === 'end') {
              try {
                if (!chunks.length) throw new Error('没有收到同步数据');
                const all = new Uint8Array(total);
                let offset = 0;
                chunks.forEach(function (chunk) { all.set(chunk, offset); offset += chunk.length; });
                if (expected && all.length !== expected) throw new Error('同步数据不完整');
                const blob = await decryptBytes(all, invite.key);
                if (onProgress) onProgress({ phase: 'restoring', received: total, total: total });
                const result = await restoreSnapshot(blob);
                finish(null, result);
              } catch (err) {
                finish(err);
              }
              return;
            }
            if (message instanceof ArrayBuffer || ArrayBuffer.isView(message)) {
              const chunk = message instanceof ArrayBuffer ? new Uint8Array(message) : new Uint8Array(message.buffer, message.byteOffset, message.byteLength);
              chunks.push(chunk);
              total += chunk.length;
              if (onProgress) onProgress({ phase: 'receiving', received: total, total: expected || total });
            }
          });
          conn.on('error', function (err) { finish(new Error(err && err.message ? err.message : '数据连接失败')); });
          conn.on('close', function () { if (!settled && total > 0) finish(new Error('主机连接断开，同步未完成')); });
        });
      } catch (err) {
        finish(err);
      }
    });
  }

  LR.sync = {
    TTL_MS: TTL_MS,
    DEFAULT_PUBLIC_BASE: DEFAULT_PUBLIC_BASE,
    isNativeHost: isNativeHost,
    startLanHost: startLanHost,
    stopLanHost: stopLanHost,
    joinLan: joinLan,
    getLanState: function () { return lanSession; },
    startPublicHost: startPublicHost,
    stopPublicHost: stopPublicHost,
    getPublicState: function () { return publicSession; },
    parsePublicInvite: parsePublicInvite,
    joinPublic: joinPublic,
    getInviteFromUrl: getInviteFromUrl,
    consumeInvite: consumeInvite,
    randomCode: randomCode
  };

  // A public sync link uses the URL fragment, so the encryption key never
  // reaches the static host or the PeerJS signaling server.
  const incoming = getInviteFromUrl();
  if (incoming) {
    try { sessionStorage.setItem('lr-public-invite', JSON.stringify(incoming)); } catch (_) {}
    try {
      history.replaceState(null, '', location.pathname + location.search + '#/settings');
      setTimeout(function () {
        if (window.App && App.navigate) App.navigate('#/settings', { replace: true });
      }, 80);
    } catch (_) {}
  }
})();
