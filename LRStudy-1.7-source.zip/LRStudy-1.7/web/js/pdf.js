/* LRStudy v1.7 — dependency-free A4 practice-paper PDF generator.
   Pages are typeset to canvas, embedded as JPEGs in a minimal PDF.
   This keeps Chinese typography correct without shipping a font file. */
(function () {
  'use strict';

  const LR = window.LR;
  const A4 = { width: 1240, height: 1754 };
  const MARGIN_X = 96;
  const TOP = 100;
  const BOTTOM = 118;
  const CONTENT_BOTTOM = A4.height - 142;
  const FONT_SANS = '"PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif';
  const FONT_SERIF = '"Songti SC", "STSong", "Noto Serif CJK SC", "Noto Serif SC", "Times New Roman", serif';
  const FONT_MONO = '"SFMono-Regular", "Menlo", "Consolas", "Noto Sans Mono", monospace';

  function font(size, weight, family) {
    return (weight || 400) + ' ' + size + 'px ' + (family || FONT_SANS);
  }

  function wrapLines(ctx, text, maxWidth) {
    const rawLines = String(text == null ? '' : text).replace(/\r\n/g, '\n').split('\n');
    const output = [];
    rawLines.forEach(function (raw) {
      if (!raw) { output.push(''); return; }
      let line = '';
      const chars = Array.from(raw);
      for (let i = 0; i < chars.length; i++) {
        const test = line + chars[i];
        if (line && ctx.measureText(test).width > maxWidth) {
          output.push(line);
          line = chars[i] === ' ' ? '' : chars[i];
        } else {
          line = test;
        }
      }
      if (line) output.push(line);
    });
    return output;
  }

  function drawLines(ctx, lines, x, y, lineHeight) {
    lines.forEach(function (line, i) {
      ctx.fillText(line, x, y + i * lineHeight);
    });
    return y + lines.length * lineHeight;
  }

  function drawDashedRect(ctx, x, y, w, h) {
    ctx.save();
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;
    ctx.setLineDash([9, 7]);
    ctx.strokeRect(x, y, w, h);
    ctx.restore();
  }

  function drawThinLine(ctx, x1, y1, x2, y2, width) {
    ctx.save();
    ctx.strokeStyle = '#000';
    ctx.lineWidth = width || 1;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.restore();
  }

  function drawAnswerLines(ctx, x, y, width) {
    ctx.save();
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 6]);
    ctx.beginPath();
    ctx.moveTo(x, y + 38);
    ctx.lineTo(x + width, y + 38);
    ctx.moveTo(x, y + 92);
    ctx.lineTo(x + width, y + 92);
    ctx.stroke();
    ctx.restore();
  }

  function buildPDFFromJPEGs(images) {
    const chunks = [];
    let offset = 0;
    const offsets = [];
    function pushBytes(bytes) {
      chunks.push(bytes);
      offset += bytes.length;
    }
    function pushText(text) {
      pushBytes(new TextEncoder().encode(text));
    }
    function beginObject(number) {
      offsets[number] = offset;
      pushText(number + ' 0 obj\n');
    }
    function endObject() {
      pushText('endobj\n');
    }

    pushText('%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n');

    const pageCount = images.length;
    const pageObjNumbers = [];
    for (let i = 0; i < pageCount; i++) pageObjNumbers.push(3 + i * 3);

    beginObject(1);
    pushText('<< /Type /Catalog /Pages 2 0 R >>\n');
    endObject();

    beginObject(2);
    pushText('<< /Type /Pages /Kids [' + pageObjNumbers.map(function (n) { return n + ' 0 R'; }).join(' ') + '] /Count ' + pageCount + ' >>\n');
    endObject();

    images.forEach(function (image, i) {
      const pageNum = 3 + i * 3;
      const imageNum = pageNum + 1;
      const contentNum = pageNum + 2;
      const content = 'q\n595 0 0 842 0 0 cm\n/Im0 Do\nQ\n';
      const contentLength = new TextEncoder().encode(content).length;

      beginObject(pageNum);
      pushText('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im0 ' + imageNum + ' 0 R >> >> /Contents ' + contentNum + ' 0 R >>\n');
      endObject();

      beginObject(imageNum);
      pushText('<< /Type /XObject /Subtype /Image /Width ' + image.width + ' /Height ' + image.height + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + image.bytes.length + ' >>\nstream\n');
      pushBytes(image.bytes);
      pushText('\nendstream\n');
      endObject();

      beginObject(contentNum);
      pushText('<< /Length ' + contentLength + ' >>\nstream\n' + content + 'endstream\n');
      endObject();
    });

    const objectCount = 2 + pageCount * 3;
    const xrefStart = offset;
    pushText('xref\n0 ' + (objectCount + 1) + '\n');
    pushText('0000000000 65535 f \n');
    for (let i = 1; i <= objectCount; i++) {
      pushText(String(offsets[i] || 0).padStart(10, '0') + ' 00000 n \n');
    }
    pushText('trailer\n<< /Size ' + (objectCount + 1) + ' /Root 1 0 R >>\nstartxref\n' + xrefStart + '\n%%EOF\n');
    return new Blob(chunks, { type: 'application/pdf' });
  }

  async function buildPracticePDF(session, options) {
    const opts = options || {};
    const includeAnswers = !!opts.includeAnswers;
    const state = LR.db.state;
    const notebook = LR.db.notebook(session.notebookId);
    const title = String(session.title || '复习练习');
    const nickname = String(state.profile.nickname || '学习者');
    const questions = Array.isArray(session.questions) ? session.questions : [];
    const kps = Array.isArray(session.knowledgePoints) ? session.knowledgePoints : [];
    const images = [];
    let canvas = null;
    let ctx = null;
    let y = TOP;
    let pageNo = 0;
    let hasContentOnPage = false;
    let totalQuestionsDrawn = 0;

    function createCanvas() {
      const c = document.createElement('canvas');
      c.width = A4.width;
      c.height = A4.height;
      const context = c.getContext('2d');
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, A4.width, A4.height);
      context.fillStyle = '#000000';
      context.textBaseline = 'top';
      return { canvas: c, ctx: context };
    }

    function encodeCurrentPage() {
      if (!canvas) return;
      if (pageNo > 0) {
        // Footer
        ctx.save();
        drawThinLine(ctx, MARGIN_X, A4.height - 96, A4.width - MARGIN_X, A4.height - 96, 1);
        ctx.font = font(18, 400, FONT_MONO);
        ctx.fillStyle = '#000';
        ctx.fillText('LRStudy v1.7 · ' + nickname, MARGIN_X, A4.height - 78);
        const pageLabel = '第 ' + pageNo + ' 页';
        const labelWidth = ctx.measureText(pageLabel).width;
        ctx.fillText(pageLabel, A4.width - MARGIN_X - labelWidth, A4.height - 78);
        ctx.restore();
        const dataURL = canvas.toDataURL('image/jpeg', 0.91);
        const b64 = dataURL.slice(dataURL.indexOf(',') + 1);
        const binary = atob(b64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        images.push({ width: A4.width, height: A4.height, bytes: bytes });
      }
      canvas = null;
      ctx = null;
    }

    function newPage(kind) {
      encodeCurrentPage();
      pageNo += 1;
      const created = createCanvas();
      canvas = created.canvas;
      ctx = created.ctx;
      y = TOP;
      hasContentOnPage = false;
      const wrongPrint = session.kind === 'wrong-print';
      if (kind === 'answer') {
        ctx.font = font(22, 400, FONT_MONO);
        ctx.fillText('LRSTUDY / ANSWER KEY', MARGIN_X, y);
        y += 34;
        ctx.font = font(52, 700, FONT_SERIF);
        ctx.fillText('参考答案', MARGIN_X, y);
        y += 70;
        drawThinLine(ctx, MARGIN_X, y, A4.width - MARGIN_X, y, 3);
        y += 48;
      } else if (pageNo === 1) {
        drawCoverHeader();
      } else {
        ctx.font = font(21, 400, FONT_MONO);
        ctx.fillText('LRSTUDY / AI PRACTICE PAPER', MARGIN_X, y);
        y += 32;
        ctx.font = font(28, 700, FONT_SANS);
        const titleLines = wrapLines(ctx, title, A4.width - MARGIN_X * 2).slice(0, 1);
        if (ctx.measureText(titleLines[0] || '').width > A4.width - MARGIN_X * 2) {
          ctx.fillText((titleLines[0] || title).slice(0, 30) + '…', MARGIN_X, y);
        } else {
          ctx.fillText(titleLines[0] || title, MARGIN_X, y);
        }
        y += 36;
        drawThinLine(ctx, MARGIN_X, y, A4.width - MARGIN_X, y, 2);
        y += 44;
      }
      return ctx;
    }

    function drawCoverHeader() {
      ctx.font = font(20, 400, FONT_MONO);
      ctx.fillText(session.kind === 'wrong-print' ? 'LRSTUDY / WRONG QUESTION PRINT' : 'LRSTUDY / AI PRACTICE PAPER', MARGIN_X, y);
      y += 38;
      ctx.font = font(56, 700, FONT_SERIF);
      const titleLines = wrapLines(ctx, title, A4.width - MARGIN_X * 2);
      y = drawLines(ctx, titleLines.slice(0, 2), MARGIN_X, y, 64);
      y += 8;
      ctx.font = font(23, 400, FONT_SANS);
      const meta = '错题本：' + (notebook ? notebook.name : session.notebookName || '—') +
        '    生成：' + LR.formatDate(session.createdAt) +
        '    共 ' + questions.length + ' 题    姓名：__________    得分：________';
      const metaLines = wrapLines(ctx, meta, A4.width - MARGIN_X * 2);
      y = drawLines(ctx, metaLines, MARGIN_X, y, 32);
      y += 20;
      drawThinLine(ctx, MARGIN_X, y, A4.width - MARGIN_X, y, 3);
      y += 30;
      if (kps.length) {
        ctx.font = font(22, 400, FONT_SANS);
        const kpText = '常错知识点：' + kps.slice(0, 12).join(' / ');
        const kpLines = wrapLines(ctx, kpText, A4.width - MARGIN_X * 2);
        y = drawLines(ctx, kpLines, MARGIN_X, y, 32);
      }
      y += 22;
      // Instruction box
      ctx.font = font(22, 400, FONT_SANS);
      const instruction = session.kind === 'wrong-print'
        ? '请独立完成并保留过程。本卷由选中的未掌握错题组成，最后一页附参考答案与解析。'
        : '请独立完成并保留过程。完成后，可用 LRStudy 的「拍照批改」上传答题页，AI 会自动打分并给出错题反馈。';
      const lines = wrapLines(ctx, instruction, A4.width - MARGIN_X * 2 - 40);
      const boxH = lines.length * 32 + 38;
      drawDashedRect(ctx, MARGIN_X, y, A4.width - MARGIN_X * 2, boxH);
      y = drawLines(ctx, lines, MARGIN_X + 20, y + 19, 32);
      y += 34;
      hasContentOnPage = true;
    }

    function ensureSomeSpace(height) {
      if (y + height > CONTENT_BOTTOM) {
        newPage('paper');
      }
    }

    function drawQuestion(question, index) {
      // Start a new page if less than a useful amount of space remains.
      if (hasContentOnPage && y + 150 > CONTENT_BOTTOM) newPage('paper');
      hasContentOnPage = true;
      ctx.font = font(42, 700, FONT_SERIF);
      ctx.fillText(String(index + 1).padStart(2, '0'), MARGIN_X, y);
      const qx = MARGIN_X + 78;
      const maxWidth = A4.width - MARGIN_X - qx;
      ctx.font = font(22, 400, FONT_MONO);
      ctx.fillText((question.knowledgePoint || '综合') + (question.difficulty ? ' / ' + question.difficulty : ''), qx, y + 3);
      y += 40;
      if (question._image) {
        const img = question._image;
        const availW = maxWidth;
        const availH = Math.max(160, CONTENT_BOTTOM - y - 150);
        const scale = Math.min(availW / img.naturalWidth, availH / img.naturalHeight, 1);
        const drawW = Math.max(1, Math.round(img.naturalWidth * scale));
        const drawH = Math.max(1, Math.round(img.naturalHeight * scale));
        if (y + drawH + 120 > CONTENT_BOTTOM) newPage('paper');
        ctx.drawImage(img, qx, y, drawW, drawH);
        y += drawH + 12;
        if (question.question) {
          ctx.font = font(22, 400, FONT_SANS);
          const extra = wrapLines(ctx, question.question, maxWidth);
          extra.slice(0, 4).forEach(function (line) {
            if (y + 34 > CONTENT_BOTTOM) return;
            ctx.fillText(line, qx, y);
            y += 32;
          });
        }
        const answerHeightImg = 88;
        if (y + answerHeightImg > CONTENT_BOTTOM) newPage('paper');
        ctx.font = font(23, 400, FONT_SANS);
        ctx.fillText('答：', qx, y);
        drawAnswerLines(ctx, qx, y, maxWidth);
        y += answerHeightImg;
        drawThinLine(ctx, MARGIN_X, y, A4.width - MARGIN_X, y, 1);
        y += 30;
        totalQuestionsDrawn += 1;
        return;
      }
      ctx.font = font(26, 400, FONT_SANS);
      const qLines = wrapLines(ctx, question.question || '', maxWidth);
      // Draw lines with page continuation.
      qLines.forEach(function (line, i) {
        if (y + 42 > CONTENT_BOTTOM - 20) {
          newPage('paper');
          ctx.font = font(26, 400, FONT_SANS);
          ctx.fillStyle = '#000';
          ctx.fillText('（第 ' + (index + 1) + ' 题续）', MARGIN_X, y);
          y += 42;
        }
        ctx.fillText(line, qx, y);
        y += 43;
        void i;
      });
      y += 10;
      const answerHeight = 118;
      if (y + answerHeight > CONTENT_BOTTOM) {
        newPage('paper');
        ctx.font = font(24, 400, FONT_SANS);
        ctx.fillText('第 ' + (index + 1) + ' 题 · 作答区（续）', qx, y);
        y += 38;
      }
      ctx.font = font(23, 400, FONT_SANS);
      ctx.fillText('答：', qx, y);
      drawAnswerLines(ctx, qx, y, maxWidth);
      y += answerHeight;
      drawThinLine(ctx, MARGIN_X, y, A4.width - MARGIN_X, y, 1);
      y += 34;
      totalQuestionsDrawn += 1;
    }

    function drawAnswerKey(question, index) {
      if (hasContentOnPage && y + 120 > CONTENT_BOTTOM) newPage('answer');
      hasContentOnPage = true;
      ctx.font = font(25, 700, FONT_SANS);
      ctx.fillText('第 ' + (index + 1) + ' 题 · ' + (question.knowledgePoint || '综合'), MARGIN_X, y);
      y += 38;
      ctx.font = font(25, 400, FONT_SANS);
      const lines = wrapLines(ctx, question.answer || '（无参考答案）', A4.width - MARGIN_X * 2);
      lines.forEach(function (line) {
        if (y + 38 > CONTENT_BOTTOM) {
          newPage('answer');
          ctx.font = font(25, 400, FONT_SANS);
        }
        ctx.fillText(line, MARGIN_X, y);
        y += 38;
      });
      y += 12;
      drawThinLine(ctx, MARGIN_X, y, A4.width - MARGIN_X, y, 1);
      y += 30;
    }

    // Wrong-question print items carry their original image. Decode them before
    // laying out pages so the image can be measured and fitted on the A4 sheet.
    const imageItems = questions.filter(function (q) { return q && q.imageDataURL; });
    if (imageItems.length) {
      await Promise.all(imageItems.map(function (q) {
        return new Promise(function (resolve) {
          const img = new Image();
          img.onload = function () { q._image = img; resolve(); };
          img.onerror = function () { resolve(); };
          img.src = q.imageDataURL;
        });
      }));
    }

    newPage('paper');
    hasContentOnPage = true;
    questions.forEach(function (question, index) {
      drawQuestion(question, index);
    });

    if (includeAnswers) {
      encodeCurrentPage();
      hasContentOnPage = false;
      newPage('answer');
      hasContentOnPage = true;
      questions.forEach(function (question, index) {
        drawAnswerKey(question, index);
      });
    }
    encodeCurrentPage();
    if (!images.length) throw new Error('没有可导出的页面');

    const blob = buildPDFFromJPEGs(images);
    const filename = 'LRStudy-' + LR.safeFilename(title) + '.pdf';
    return {
      blob: blob,
      filename: filename,
      pages: images.length,
      questionCount: totalQuestionsDrawn
    };
  }

  LR.pdf = {
    buildPracticePDF: buildPracticePDF,
    buildPDFFromJPEGs: buildPDFFromJPEGs
  };
})();
