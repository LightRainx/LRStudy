/* LRStudy v1.7 — question region detection, cropping and ink cleanup */
(function () {
  'use strict';

  const LR = window.LR;

  function otsuThreshold(histogram, total) {
    let sum = 0;
    for (let i = 0; i < 256; i++) sum += i * histogram[i];
    let sumB = 0;
    let wB = 0;
    let best = 0;
    let bestVariance = -1;
    for (let t = 0; t < 256; t++) {
      wB += histogram[t];
      if (!wB) continue;
      const wF = total - wB;
      if (!wF) break;
      sumB += t * histogram[t];
      const mB = sumB / wB;
      const mF = (sum - sumB) / wF;
      const between = wB * wF * (mB - mF) * (mB - mF);
      if (between > bestVariance) {
        bestVariance = between;
        best = t;
      }
    }
    return best;
  }

  function percentileFromHistogram(hist, total, percentile) {
    const target = total * percentile;
    let acc = 0;
    for (let i = 0; i < 256; i++) {
      acc += hist[i];
      if (acc >= target) return i;
    }
    return 255;
  }

  /**
   * Build an illumination-normalized grayscale buffer plus an ink mask.
   * The local background is estimated from coarse cells so phone-photo
   * shadows do not turn the whole page into "ink".
   */
  function analyzeCanvas(canvas) {
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const width = canvas.width;
    const height = canvas.height;
    const data = ctx.getImageData(0, 0, width, height).data;
    const gray = new Uint8Array(width * height);
    for (let i = 0, j = 0; i < data.length; i += 4, j++) {
      gray[j] = Math.round(data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114);
    }

    const cell = Math.max(18, Math.round(Math.min(width, height) / 32));
    const cols = Math.max(1, Math.ceil(width / cell));
    const rows = Math.max(1, Math.ceil(height / cell));
    const backgrounds = new Float32Array(cols * rows);
    const globalHist = new Uint32Array(256);

    for (let gy = 0; gy < rows; gy++) {
      for (let gx = 0; gx < cols; gx++) {
        const hist = new Uint32Array(256);
        let count = 0;
        const x0 = gx * cell;
        const y0 = gy * cell;
        const x1 = Math.min(width, x0 + cell);
        const y1 = Math.min(height, y0 + cell);
        for (let y = y0; y < y1; y += 2) {
          for (let x = x0; x < x1; x += 2) {
            const v = gray[y * width + x];
            hist[v]++;
            globalHist[v]++;
            count++;
          }
        }
        backgrounds[gy * cols + gx] = count ? percentileFromHistogram(hist, count, 0.72) : 255;
      }
    }

    // Smooth the background map to avoid seams between cells.
    const smoothed = new Float32Array(backgrounds.length);
    for (let gy = 0; gy < rows; gy++) {
      for (let gx = 0; gx < cols; gx++) {
        let sum = 0;
        let n = 0;
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            const yy = gy + dy;
            const xx = gx + dx;
            if (yy >= 0 && yy < rows && xx >= 0 && xx < cols) {
              sum += backgrounds[yy * cols + xx];
              n++;
            }
          }
        }
        smoothed[gy * cols + gx] = sum / n;
      }
    }

    const normalized = new Uint8Array(width * height);
    const localHist = new Uint32Array(256);
    for (let y = 0; y < height; y++) {
      const fy = Math.min(rows - 1.001, Math.max(0, y / cell - 0.5));
      const y0 = Math.floor(fy);
      const y1 = Math.min(rows - 1, y0 + 1);
      const ty = fy - y0;
      for (let x = 0; x < width; x++) {
        const fx = Math.min(cols - 1.001, Math.max(0, x / cell - 0.5));
        const x0 = Math.floor(fx);
        const x1 = Math.min(cols - 1, x0 + 1);
        const tx = fx - x0;
        const bg =
          smoothed[y0 * cols + x0] * (1 - tx) * (1 - ty) +
          smoothed[y0 * cols + x1] * tx * (1 - ty) +
          smoothed[y1 * cols + x0] * (1 - tx) * ty +
          smoothed[y1 * cols + x1] * tx * ty;
        const divisor = Math.max(40, bg);
        const value = LR.clamp(Math.round((gray[y * width + x] / divisor) * 235), 0, 255);
        normalized[y * width + x] = value;
        localHist[value]++;
      }
    }

    const total = width * height;
    const threshold = Math.min(205, Math.max(82, otsuThreshold(localHist, total) + 4));
    const mask = new Uint8Array(width * height);
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = y * width + x;
        if (normalized[idx] < threshold) mask[idx] = 1;
      }
    }

    void globalHist;
    return { mask: mask, width: width, height: height, threshold: threshold, cell: cell };
  }

  function fillShortGaps(flags, maxGap) {
    let last = -1;
    for (let i = 0; i < flags.length; i++) {
      if (flags[i]) {
        if (last >= 0 && i - last - 1 <= maxGap) {
          for (let j = last + 1; j < i; j++) flags[j] = 1;
        }
        last = i;
      }
    }
  }

  function removeShortRuns(flags, minRun) {
    let start = -1;
    for (let i = 0; i <= flags.length; i++) {
      const active = i < flags.length ? !!flags[i] : false;
      if (active && start < 0) start = i;
      if (!active && start >= 0) {
        if (i - start < minRun) {
          for (let j = start; j < i; j++) flags[j] = 0;
        }
        start = -1;
      }
    }
  }

  function median(values) {
    if (!values.length) return 0;
    const sorted = values.slice().sort(function (a, b) { return a - b; });
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
  }

  /**
   * Auto-detect separate question regions.
   * Returns normalized rectangles: [{x,y,w,h}] in 0..1 coordinates.
   */
  LR.segmentQuestions = function (canvas) {
    if (!canvas || !canvas.width || !canvas.height) return [];
    const { mask, width, height } = analyzeCanvas(canvas);
    const marginX = Math.round(width * 0.018);
    const marginY = Math.round(height * 0.012);
    const minRowInk = Math.max(2, Math.round(width * 0.0016));
    const rowFlags = new Uint8Array(height);

    for (let y = marginY; y < height - marginY; y++) {
      let count = 0;
      const base = y * width;
      for (let x = marginX; x < width - marginX; x++) {
        if (mask[base + x]) count++;
        if (count >= minRowInk) { rowFlags[y] = 1; break; }
      }
    }

    fillShortGaps(rowFlags, 2);
    removeShortRuns(rowFlags, 2);

    const runs = [];
    let runStart = -1;
    for (let y = 0; y <= height; y++) {
      const active = y < height ? !!rowFlags[y] : false;
      if (active && runStart < 0) runStart = y;
      if (!active && runStart >= 0) {
        runs.push({ start: runStart, end: y - 1 });
        runStart = -1;
      }
    }
    if (!runs.length) return [];

    const gaps = [];
    for (let i = 1; i < runs.length; i++) {
      const gap = runs[i].start - runs[i - 1].end - 1;
      if (gap > 0) gaps.push(gap);
    }
    const lineGaps = gaps.filter(function (g) { return g <= Math.max(12, height * 0.018); });
    const typicalGap = median(lineGaps) || 5;
    let splitGap = LR.clamp(typicalGap * 2.15, Math.max(10, height * 0.009), Math.max(20, height * 0.035));

    function groupByGap(threshold) {
      const blocks = [];
      let current = { start: runs[0].start, end: runs[0].end };
      for (let i = 1; i < runs.length; i++) {
        const gap = runs[i].start - runs[i - 1].end - 1;
        if (gap >= threshold) {
          blocks.push(current);
          current = { start: runs[i].start, end: runs[i].end };
        } else {
          current.end = runs[i].end;
        }
      }
      blocks.push(current);
      return blocks;
    }

    let blocks = groupByGap(splitGap);

    // If the page came out as a single giant block, split it at its largest gaps.
    if (blocks.length === 1 && runs.length > 2) {
      const blockHeight = blocks[0].end - blocks[0].start;
      if (blockHeight > height * 0.22) {
        const desired = LR.clamp(Math.round(blockHeight / (height * 0.24)), 2, 5);
        const internal = [];
        for (let i = 1; i < runs.length; i++) {
          internal.push({
            index: i,
            gap: runs[i].start - runs[i - 1].end - 1,
            pos: runs[i].start
          });
        }
        internal.sort(function (a, b) { return b.gap - a.gap; });
        const chosen = internal
          .filter(function (item) { return item.gap >= Math.max(3, splitGap * 0.28); })
          .slice(0, desired - 1)
          .sort(function (a, b) { return a.pos - b.pos; });
        if (chosen.length) {
          const chosenStarts = new Set(chosen.map(function (item) { return runs[item.index].start; }));
          const forced = [];
          let current = { start: runs[0].start, end: runs[0].end };
          for (let i = 1; i < runs.length; i++) {
            if (chosenStarts.has(runs[i].start)) {
              forced.push(current);
              current = { start: runs[i].start, end: runs[i].end };
            } else {
              current.end = runs[i].end;
            }
          }
          forced.push(current);
          blocks = forced;
        }
      }
    }

    // Merge only noise-sized blocks. A one-line question is still a question.
    const minHeight = Math.max(6, height * 0.006);
    const merged = [];
    blocks.forEach(function (block) {
      const h = block.end - block.start + 1;
      if (h < minHeight && merged.length) {
        merged[merged.length - 1].end = block.end;
      } else {
        merged.push({ start: block.start, end: block.end });
      }
    });
    if (merged.length >= 2) {
      const first = merged[0];
      if (first.end - first.start + 1 < minHeight * 0.9) {
        merged[1].start = first.start;
        merged.shift();
      }
    }

    const boxes = merged.map(function (block) {
      let minX = width;
      let maxX = 0;
      let minY = height;
      let maxY = 0;
      for (let y = block.start; y <= block.end; y++) {
        const base = y * width;
        for (let x = marginX; x < width - marginX; x++) {
          if (mask[base + x]) {
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
          }
        }
      }
      if (maxX <= minX || maxY < minY) return null;
      // Keep a readable column width. A single short line (e.g. a heading)
      // should not produce a tiny box.
      const padX = Math.max(width * 0.018, (maxX - minX) * 0.045);
      const padY = Math.max(height * 0.005, 6);
      let x0 = Math.max(0, minX - padX);
      let x1 = Math.min(width, maxX + padX);
      let y0 = Math.max(0, minY - padY);
      let y1 = Math.min(height, maxY + padY);
      const minWidth = width * 0.3;
      if (x1 - x0 < minWidth) {
        const center = (x0 + x1) / 2;
        x0 = Math.max(0, center - minWidth / 2);
        x1 = Math.min(width, x0 + minWidth);
        if (x1 - x0 < minWidth) x0 = Math.max(0, x1 - minWidth);
      }
      if (y1 - y0 < minHeight) y1 = Math.min(height, y0 + minHeight);
      return {
        x: x0 / width,
        y: y0 / height,
        w: (x1 - x0) / width,
        h: (y1 - y0) / height
      };
    }).filter(Boolean);

    // De-duplicate nearly identical boxes.
    const unique = [];
    boxes.forEach(function (box) {
      const duplicate = unique.some(function (b) {
        return Math.abs(b.x - box.x) < 0.02 && Math.abs(b.y - box.y) < 0.012 &&
          Math.abs(b.w - box.w) < 0.03 && Math.abs(b.h - box.h) < 0.02;
      });
      if (!duplicate) unique.push(box);
    });

    unique.sort(function (a, b) { return a.y - b.y || a.x - b.x; });
    return unique.slice(0, 18);
  };

  /**
   * Remove colored handwriting (red / blue / green pen) while preserving
   * neutral printed text and dark pencil. Leaves black ink untouched.
   */
  LR.removeColoredInk = function (canvas) {
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = image.data;
    const width = canvas.width;
    const height = canvas.height;
    const total = width * height;
    const mask = new Uint8Array(total);

    // Estimate the paper tone from bright, nearly neutral pixels. Colored ink
    // is filled with this tone instead of pure white, so a warm/off-white page
    // does not end up looking over-exposed.
    let paperR = 255, paperG = 255, paperB = 255;
    let paperCount = 0;
    let sumR = 0, sumG = 0, sumB = 0;
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const high = Math.max(r, g, b);
      const low = Math.min(r, g, b);
      if (high > 190 && high - low < 18) {
        sumR += r; sumG += g; sumB += b; paperCount++;
      }
    }
    if (paperCount) {
      paperR = Math.round(sumR / paperCount);
      paperG = Math.round(sumG / paperCount);
      paperB = Math.round(sumB / paperCount);
    }

    let colored = 0;
    for (let p = 0; p < total; p++) {
      const i = p * 4;
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const high = Math.max(r, g, b);
      const low = Math.min(r, g, b);
      const chroma = high - low;
      const saturation = high > 0 ? chroma / high : 0;
      // Conservative: only clearly saturated red/blue/green strokes. This
      // avoids treating slightly warm paper, JPEG noise or light gray print as
      // handwriting and wiping the whole question.
      if (chroma >= 45 && saturation >= 0.28 && high >= 60) {
        mask[p] = 1;
        colored++;
      }
    }

    // A page dominated by strong color is probably a chart, colored diagram or
    // a photo rather than handwriting. Do not erase it automatically.
    if (!colored || colored > total * 0.38) return 0;

    const fill = new Uint8Array(data.length);
    fill.set(data);
    let removed = 0;
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const p = y * width + x;
        if (!mask[p]) continue;
        let r = 0, g = 0, b = 0, n = 0;
        for (let dy = -3; dy <= 3; dy++) {
          const yy = y + dy;
          if (yy < 0 || yy >= height) continue;
          for (let dx = -3; dx <= 3; dx++) {
            const xx = x + dx;
            if (xx < 0 || xx >= width) continue;
            const q = yy * width + xx;
            if (mask[q]) continue;
            const j = q * 4;
            r += data[j]; g += data[j + 1]; b += data[j + 2]; n++;
          }
        }
        const j = p * 4;
        if (n) {
          fill[j] = Math.round(r / n);
          fill[j + 1] = Math.round(g / n);
          fill[j + 2] = Math.round(b / n);
        } else {
          fill[j] = paperR; fill[j + 1] = paperG; fill[j + 2] = paperB;
        }
        fill[j + 3] = 255;
        removed++;
      }
    }
    image.data.set(fill);
    ctx.putImageData(image, 0, 0);
    return removed;
  };

  /**
   * Crop a normalized region from the source page canvas.
   * Adds white padding and caps the longest side for storage.
   */
  LR.cropPageRegion = function (pageCanvas, region, options) {
    const opts = options || {};
    const padRatio = opts.padding == null ? 0.012 : opts.padding;
    const sx = Math.round(region.x * pageCanvas.width);
    const sy = Math.round(region.y * pageCanvas.height);
    const sw = Math.max(1, Math.round(region.w * pageCanvas.width));
    const sh = Math.max(1, Math.round(region.h * pageCanvas.height));
    const padX = Math.round(pageCanvas.width * padRatio);
    const padY = Math.round(pageCanvas.height * padRatio);
    const x0 = Math.max(0, sx - padX);
    const y0 = Math.max(0, sy - padY);
    const x1 = Math.min(pageCanvas.width, sx + sw + padX);
    const y1 = Math.min(pageCanvas.height, sy + sh + padY);
    const maxSide = opts.maxSide || 1800;
    const scale = Math.min(1, maxSide / Math.max(x1 - x0, y1 - y0));
    const out = document.createElement('canvas');
    out.width = Math.max(1, Math.round((x1 - x0) * scale));
    out.height = Math.max(1, Math.round((y1 - y0) * scale));
    const ctx = out.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, out.width, out.height);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(pageCanvas, x0, y0, x1 - x0, y1 - y0, 0, 0, out.width, out.height);
    return out;
  };

  LR.pageCanvasForAnalysis = function (sourceCanvas, maxSide) {
    const limit = maxSide || 1100;
    const scale = Math.min(1, limit / Math.max(sourceCanvas.width, sourceCanvas.height));
    if (scale >= 0.999) return sourceCanvas;
    const c = document.createElement('canvas');
    c.width = Math.round(sourceCanvas.width * scale);
    c.height = Math.round(sourceCanvas.height * scale);
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, c.width, c.height);
    ctx.drawImage(sourceCanvas, 0, 0, c.width, c.height);
    return c;
  };

  LR.estimatePaperRegion = function (canvas) {
    // Reserved for future edge detection. Returns the page as a fallback.
    return { x: 0, y: 0, w: 1, h: 1 };
  };
})();
