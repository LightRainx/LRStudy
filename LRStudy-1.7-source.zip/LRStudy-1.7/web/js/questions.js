/* LRStudy v1.7 — question detail, AI analysis, ink cleaner, notebook management */
(function () {
  'use strict';

  const LR = window.LR;
  const App = window.App;
  const e = App.e;
  const attr = LR.escapeAttr;
  const icon = App.icon;
  const actions = App.actions;
  const analysisBusy = new Set();
  const analysisErrors = new Map();
  let activeQuestionId = null;
  const autoQueue = new Set();
  let autoRunning = false;

  /* --------------------------- question modal ---------------------------- */

  function analysisHTML(q) {
    if (analysisBusy.has(q.id)) {
      return '<div class="analysis-card">' +
        '<div class="analysis-card-head"><span class="analysis-card-title">' + icon('sparkle') + 'AI 错题解析</span></div>' +
        '<div class="ai-inline-loading"><span class="spinner spinner--large" aria-hidden="true"></span><p>正在阅读题目、归纳知识点…<br>图片解析通常需要 10–40 秒</p></div>' +
      '</div>';
    }
    const err = analysisErrors.get(q.id);
    const analysis = q.analysis;
    if (!analysis) {
      return '<div class="analysis-card">' +
        '<div class="analysis-card-head"><span class="analysis-card-title">' + icon('sparkle') + 'AI 错题解析</span><span class="section-note">OPTIONAL</span></div>' +
        '<div class="analysis-empty">' +
          (err ? '<p class="form-error">' + e(err) + '</p>' : '') +
          '<p>让 AI 识别题目，写出解题思路、错误原因和本题涉及的错误知识点。解析结果会用于后续复习出题。</p>' +
          '<button type="button" class="btn btn--primary btn--small" data-action="ai-analyze" data-id="' + attr(q.id) + '">' + icon('sparkle') + '生成 AI 解析</button>' +
        '</div>' +
      '</div>';
    }
    const kps = (analysis.knowledgePoints || []).slice(0, 12);
    return '<div class="analysis-card">' +
      '<div class="analysis-card-head">' +
        '<span class="analysis-card-title">' + icon('sparkle') + 'AI 错题解析</span>' +
        '<span class="section-note">' + (analysis.generatedAt ? LR.formatDate(analysis.generatedAt) : '已生成') + '</span>' +
      '</div>' +
      '<div class="analysis-card-body">' +
        (analysis.summary ? '<div class="analysis-section"><div class="analysis-label">题目解析</div><div class="analysis-text">' + LR.textToHTML(analysis.summary) + '</div></div>' : '') +
        '<div class="analysis-section">' +
          '<div class="analysis-label">错误知识点</div>' +
          (kps.length
            ? '<div class="chip-row">' + kps.map(function (k) { return '<span class="chip chip--strong">' + e(k) + '</span>'; }).join('') + '</div>'
            : '<div class="analysis-text muted">未提取到知识点，可点「编辑」手动补充。</div>') +
        '</div>' +
        (analysis.errorCause ? '<div class="analysis-section"><div class="analysis-label">错误原因</div><div class="analysis-text">' + LR.textToHTML(analysis.errorCause) + '</div></div>' : '') +
        (analysis.solutionSteps && analysis.solutionSteps.length
          ? '<div class="analysis-section"><div class="analysis-label">解题步骤</div><ol class="analysis-steps">' + analysis.solutionSteps.map(function (step) { return '<li>' + LR.textToHTML(step) + '</li>'; }).join('') + '</ol></div>'
          : '') +
        (analysis.tips ? '<div class="analysis-section"><div class="analysis-label">复习提醒</div><div class="analysis-tip">' + LR.textToHTML(analysis.tips) + '</div></div>' : '') +
        '<div class="analysis-section"><div class="inline-actions"><button type="button" class="btn btn--small btn--ghost" data-action="ai-analyze" data-id="' + attr(q.id) + '">' + icon('refresh') + '重新解析</button><span class="section-note">MODEL ' + e((analysis.model || 'AI').slice(0, 42)) + '</span></div></div>' +
      '</div>' +
    '</div>';
  }

  function questionModalHTML(q) {
    const date = LR.formatDate(q.createdAt);
    const title = q.analysis && q.analysis.subject ? q.analysis.subject : '错题详情';
    void title;
    return App.modalShell({
      eyebrow: 'RECORD / ' + date,
      title: q.title && q.title !== '拍照错题' ? q.title : '错题详情',
      body:
        '<div class="q-detail-meta">' +
          '<span class="badge">' + e(q.source === 'review' ? '复习收录' : q.ocrSource ? 'OCR 文字' : q.contentText ? '文字题' : '拍照题') + '</span>' +
          (q.mastered ? '<span class="badge badge--filled">已掌握</span>' : '<span class="badge badge--muted">待复习</span>') +
          '<span class="sr-note">' + e(date) + '</span>' +
          (q.reviewCount ? '<span class="sr-note">练习 ' + q.reviewCount + ' 次</span>' : '') +
        '</div>' +
        (q.imageId
          ? '<button type="button" class="q-image-button" data-action="view-image" data-id="' + attr(q.imageId) + '" aria-label="查看错题大图"><img class="q-detail-image" data-image-id="' + attr(q.imageId) + '" alt="错题图片"><span class="q-image-zoom">' + icon('eye') + '查看大图</span></button>'
          : '') +
        (q.contentText
          ? '<div class="q-text-block mt-16"><span class="q-text-label">' + (q.ocrSource ? 'OCR 识别文字' : '题目') + '</span>' + LR.textToHTML(q.contentText) + '</div>'
          : '') +
        (q.answerText
          ? '<details class="answer-collapse mt-12"><summary>查看参考答案</summary><div class="paper-answer"><strong>参考答案</strong><br>' + LR.textToHTML(q.answerText) + '</div></details>'
          : '') +
        (q.note ? '<div class="q-note-block"><strong>我的备注</strong>' + LR.textToHTML(q.note) + '</div>' : '') +
        '<div class="q-analysis">' + analysisHTML(q) + '</div>' +
        '<div class="q-action-grid">' +
          (q.imageId ? '<button type="button" class="btn btn--ghost" data-action="clean-ink" data-id="' + attr(q.id) + '">' + icon('eraser') + '去笔迹</button>' : '') +
          '<button type="button" class="btn btn--ghost" data-action="edit-question" data-id="' + attr(q.id) + '">' + icon('edit') + '编辑知识点</button>' +
          '<button type="button" class="btn btn--ghost" data-action="toggle-mastered" data-id="' + attr(q.id) + '">' + icon(q.mastered ? 'refresh' : 'check') + (q.mastered ? '移回待复习' : '标记已掌握') + '</button>' +
          '<button type="button" class="btn btn--ghost q-action-danger" data-action="delete-question" data-id="' + attr(q.id) + '">' + icon('trash') + '删除这道题</button>' +
        '</div>' +
        '<p class="modal-note">图片与解析保存在当前设备。AI 解析会将题目图片发送到你配置的 AI 服务。</p>',
      footer: '<button type="button" class="btn btn--ghost btn--grow" data-action="close-modal">关闭</button>'
    });
  }

  function openQuestionModal(id, options) {
    const q = LR.db.question(id);
    if (!q) {
      App.toast('这道错题不存在或已被删除', 'error');
      activeQuestionId = null;
      return;
    }
    const opts = options || {};
    // Clear the ref first so the old modal's onClose cannot erase the new one.
    activeQuestionId = null;
    const modal = App.openModal({
      html: questionModalHTML(q),
      ariaLabel: '错题详情',
      onMount: function (root) {
        App.hydrateImages(root);
        if (!opts.keepScroll) {
          const body = root.querySelector('.modal-body');
          if (body) body.scrollTop = 0;
        }
      },
      onClose: function () {
        if (activeQuestionId === id) activeQuestionId = null;
      }
    });
    activeQuestionId = id;
    return modal;
  }

  function refreshQuestionModal(id) {
    if (activeQuestionId !== id) return;
    const body = App.ui.modal && App.ui.modal.root ? App.ui.modal.root.querySelector('.modal-body') : null;
    const scroll = body ? body.scrollTop : 0;
    const modal = openQuestionModal(id, { keepScroll: true });
    if (modal) {
      const newBody = modal.root.querySelector('.modal-body');
      if (newBody) newBody.scrollTop = scroll;
    }
  }

  actions['open-question'] = function (el) {
    openQuestionModal(el.getAttribute('data-id'));
  };
  App.openQuestionModal = openQuestionModal;

  /* ------------------------------ view image ----------------------------- */

  async function openImageViewer(imageId, title, returnToQuestionId) {
    if (!imageId) return;
    const url = await LR.db.imageURL(imageId);
    if (!url) {
      App.toast('图片不存在', 'error');
      return;
    }
    App.openModal({
      size: 'viewer',
      ariaLabel: title || '查看图片',
      html:
        '<div class="modal-head">' +
          '<div class="modal-head-copy"><div class="modal-eyebrow">IMAGE</div><div class="modal-title">' + e(title || '查看大图') + '</div></div>' +
          '<button type="button" class="icon-button" data-action="close-modal" aria-label="关闭">' + icon('close') + '</button>' +
        '</div>' +
        '<div class="viewer-stage"><img src="' + attr(url) + '" alt="' + attr(title || '错题图片') + '"></div>',
      onMount: function (root) {
        const img = root.querySelector('.viewer-stage img');
        img.addEventListener('dblclick', function () {
          img.style.maxHeight = img.style.maxHeight === 'none' ? '100%' : 'none';
        });
      },
      onClose: function () {
        if (returnToQuestionId && LR.db.question(returnToQuestionId)) {
          openQuestionModal(returnToQuestionId);
        }
      }
    });
  }
  App.openImageViewer = openImageViewer;

  actions['view-image'] = function (el) {
    openImageViewer(el.getAttribute('data-id'), '错题大图', activeQuestionId);
  };

  /* ------------------------------- AI analysis --------------------------- */

  async function analyzeOne(id, options) {
    const opts = options || {};
    const q = LR.db.question(id);
    if (!q) throw new Error('错题不存在');
    if (analysisBusy.has(id)) return;
    if (!LR.ai.isConfigured()) {
      if (!opts.silent) {
        if (App.openAIConfigPrompt) App.openAIConfigPrompt('AI 解析需要先配置 API Key。配置后，软件无法完成的识图与归纳工作会交给 AI。');
        else App.navigate('#/settings');
      }
      return;
    }
    analysisBusy.add(id);
    analysisErrors.delete(id);
    if (activeQuestionId === id) refreshQuestionModal(id);
    if (!opts.silent) App.render();
    try {
      const analysis = await LR.ai.analyzeQuestion(q);
      const current = LR.db.question(id);
      if (!current) return;
      await LR.db.updateQuestion(id, { analysis: analysis, tags: analysis.knowledgePoints || [] });
      if (!opts.silent) App.toast('AI 解析完成，知识点已归档', 'success');
      if (activeQuestionId === id) refreshQuestionModal(id);
      if (App.route().page === 'notebook') App.render();
      else if (App.route().page === 'notebooks') App.render();
      return analysis;
    } catch (err) {
      console.error(err);
      analysisErrors.set(id, err.message || 'AI 解析失败');
      if (!opts.silent) App.toast('AI 解析失败：' + (err.message || '请重试'), 'error');
      if (activeQuestionId === id) refreshQuestionModal(id);
      throw err;
    } finally {
      analysisBusy.delete(id);
      if (activeQuestionId === id && !opts.silent) {
        // Ensure the loading state is removed even when the request fails early.
        const modal = App.ui.modal;
        if (modal && modal.root && modal.root.querySelector('.ai-inline-loading')) refreshQuestionModal(id);
      }
    }
  }

  actions['ai-analyze'] = async function (el) {
    const id = el.getAttribute('data-id');
    if (!id) return;
    try { await analyzeOne(id); } catch (_) {}
  };

  /* Background queue used after automatic uploads. */
  async function autoAnalyzeQuestions(ids, options) {
    const opts = options || {};
    if (!Array.isArray(ids) || !ids.length) return;
    if (!LR.ai.isConfigured()) {
      if (!opts.silent) App.toast('已上传错题。配置 API Key 后可自动生成解析。', 'info');
      return;
    }
    ids.forEach(function (id) { autoQueue.add(id); });
    if (autoRunning) return;
    autoRunning = true;
    let done = 0;
    let failed = 0;
    App.toast('AI 正在自动解析 ' + ids.length + ' 道错题…', 'info', 4200);
    try {
      while (autoQueue.size) {
        const next = autoQueue.values().next().value;
        autoQueue.delete(next);
        const q = LR.db.question(next);
        if (!q || q.analysis || analysisBusy.has(next)) continue;
        try {
          await analyzeOne(next, { silent: true });
          done++;
        } catch (err) {
          failed++;
          console.warn('自动解析失败', err);
        }
        if (App.route().page === 'notebook' || App.route().page === 'notebooks') App.render();
      }
    } finally {
      autoRunning = false;
    }
    if (done || failed) {
      if (failed) App.toast('自动解析完成 ' + done + ' 道，' + failed + ' 道失败，可在错题详情中重试', 'error');
      else App.toast('已自动生成 ' + done + ' 道错题的 AI 解析', 'success');
    }
  }
  App.autoAnalyzeQuestions = autoAnalyzeQuestions;

  /* ----------------------------- ink cleaner ----------------------------- */

  async function openInkCleaner(id) {
    const q = LR.db.question(id);
    if (!q || !q.imageId) {
      App.toast('没有可编辑的图片', 'error');
      return;
    }
    const hide = App.showBusy('正在准备图片', '载入原始错题…');
    let blob;
    try {
      blob = await LR.db.getImageBlob(q.imageId);
    } catch (err) {
      hide();
      App.toast('图片载入失败：' + err.message, 'error');
      return;
    }
    hide();
    if (!blob) {
      App.toast('图片不存在', 'error');
      return;
    }
    let sourceCanvas;
    try {
      const img = await LR.loadImageElement(blob);
      const maxSide = 1800;
      const scale = Math.min(1, maxSide / Math.max(img.naturalWidth || img.width, img.naturalHeight || img.height));
      sourceCanvas = document.createElement('canvas');
      sourceCanvas.width = Math.max(1, Math.round((img.naturalWidth || img.width) * scale));
      sourceCanvas.height = Math.max(1, Math.round((img.naturalHeight || img.height) * scale));
      const ctx = sourceCanvas.getContext('2d');
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, sourceCanvas.width, sourceCanvas.height);
      ctx.drawImage(img, 0, 0, sourceCanvas.width, sourceCanvas.height);
    } catch (err) {
      App.toast('图片打开失败：' + (err.message || '请重试'), 'error');
      return;
    }

    const modal = App.openBasicModal({
      title: '去笔迹',
      eyebrow: 'CLEAN / INK',
      body:
        '<div class="ink-editor">' +
          '<div class="notice">' + icon('info') + '<span><strong>自动去除彩色笔迹</strong>会清除红、蓝、绿等彩色笔画；<strong>橡皮擦</strong>可手动擦掉任意笔迹，包括黑笔。原图不会被销毁，保存前可撤销或重置。</span></div>' +
          '<div class="ink-canvas-wrap"><canvas id="inkCanvas"></canvas></div>' +
          '<div class="ink-tools">' +
            '<div class="range-wrap"><span>笔刷</span><input type="range" id="inkBrush" min="8" max="80" value="30" aria-label="橡皮擦大小"><span id="inkBrushValue">30</span></div>' +
            '<button type="button" class="btn btn--small btn--ghost" id="inkUndo">' + icon('undo') + '撤销</button>' +
            '<button type="button" class="btn btn--small btn--ghost" id="inkAuto">' + icon('sparkle') + '去除彩色笔迹</button>' +
            '<button type="button" class="btn btn--small btn--ghost" id="inkReset">' + icon('refresh') + '重置</button>' +
          '</div>' +
          '<p class="hint">在图片上拖动即可擦除。撤销最多可回退 6 步。编辑只影响本地副本。</p>' +
        '</div>',
      footer: '<button type="button" class="btn btn--ghost btn--grow" id="inkCancel">取消</button>' +
        '<button type="button" class="btn btn--primary btn--grow" id="inkSave">保存修改</button>',
      onMount: function (root) {
        const canvas = root.querySelector('#inkCanvas');
        canvas.width = sourceCanvas.width;
        canvas.height = sourceCanvas.height;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        ctx.drawImage(sourceCanvas, 0, 0);
        const original = canvas.toDataURL('image/png');
        const history = [];
        let drawing = false;
        let last = null;
        let brush = 30;
        const range = root.querySelector('#inkBrush');
        const rangeValue = root.querySelector('#inkBrushValue');
        range.addEventListener('input', function () {
          brush = Number(range.value) || 30;
          rangeValue.textContent = String(brush);
        });

        function pushHistory() {
          history.push(canvas.toDataURL('image/png'));
          if (history.length > 6) history.shift();
        }
        function point(event) {
          const rect = canvas.getBoundingClientRect();
          return {
            x: (event.clientX - rect.left) / rect.width * canvas.width,
            y: (event.clientY - rect.top) / rect.height * canvas.height
          };
        }
        function strokeTo(p) {
          ctx.strokeStyle = '#ffffff';
          ctx.fillStyle = '#ffffff';
          ctx.lineWidth = brush * (canvas.width / Math.max(1, canvas.getBoundingClientRect().width || canvas.width));
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          if (last) {
            ctx.beginPath();
            ctx.moveTo(last.x, last.y);
            ctx.lineTo(p.x, p.y);
            ctx.stroke();
          }
          ctx.beginPath();
          ctx.arc(p.x, p.y, ctx.lineWidth / 2, 0, Math.PI * 2);
          ctx.fill();
          last = p;
        }
        canvas.addEventListener('pointerdown', function (event) {
          event.preventDefault();
          pushHistory();
          drawing = true;
          last = null;
          canvas.setPointerCapture(event.pointerId);
          strokeTo(point(event));
        });
        canvas.addEventListener('pointermove', function (event) {
          if (!drawing) return;
          event.preventDefault();
          strokeTo(point(event));
        });
        function end(event) {
          if (!drawing) return;
          drawing = false;
          last = null;
          try { canvas.releasePointerCapture(event.pointerId); } catch (_) {}
        }
        canvas.addEventListener('pointerup', end);
        canvas.addEventListener('pointercancel', end);

        root.querySelector('#inkUndo').addEventListener('click', function () {
          const previous = history.pop();
          if (!previous) { App.toast('没有可撤销的操作', 'info'); return; }
          const img = new Image();
          img.onload = function () {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0);
          };
          img.src = previous;
        });
        root.querySelector('#inkAuto').addEventListener('click', function () {
          pushHistory();
          const count = LR.removeColoredInk(canvas);
          if (count > 0) App.toast('已清除 ' + count.toLocaleString('zh-CN') + ' 个彩色像素', 'success');
          else App.toast('没有检测到彩色笔迹', 'info');
        });
        root.querySelector('#inkReset').addEventListener('click', function () {
          pushHistory();
          const img = new Image();
          img.onload = function () {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0);
            App.toast('已重置为原始图片', 'info');
          };
          img.src = original;
        });
        root.querySelector('#inkCancel').addEventListener('click', function () {
          App.closeModal();
          openQuestionModal(id);
        });
        root.querySelector('#inkSave').addEventListener('click', async function () {
          const btn = root.querySelector('#inkSave');
          if (btn.disabled) return;
          btn.disabled = true;
          const hide = App.showBusy('正在保存笔迹', '更新本地错题图片…');
          try {
            const newBlob = await LR.canvasToBlob(canvas, 'image/jpeg', 0.9);
            await LR.db.saveImage(newBlob, { id: q.imageId });
            await LR.db.updateQuestion(id, { imageWidth: canvas.width, imageHeight: canvas.height });
            hide();
            App.closeModal();
            App.toast('笔迹修改已保存', 'success');
            App.render();
            openQuestionModal(id);
          } catch (err) {
            hide();
            btn.disabled = false;
            App.toast('保存失败：' + (err.message || '请重试'), 'error');
          }
        });
      }
    });
    void modal;
  }

  actions['clean-ink'] = function (el) {
    openInkCleaner(el.getAttribute('data-id'));
  };

  /* --------------------------- edit question ----------------------------- */

  function openEditQuestion(id) {
    const q = LR.db.question(id);
    if (!q) return;
    const currentPoints = (q.analysis && q.analysis.knowledgePoints && q.analysis.knowledgePoints.length)
      ? q.analysis.knowledgePoints.join('、')
      : (q.tags || []).join('、');
    App.openBasicModal({
      title: '编辑错题信息',
      eyebrow: 'EDIT / RECORD',
      center: true,
      body:
        '<form id="editQuestionForm">' +
          '<div class="field"><label for="qEditKps">错误知识点</label><textarea class="textarea textarea--short" id="qEditKps" placeholder="用顿号或逗号分隔，例如：二次函数、判别式">' + e(currentPoints) + '</textarea><p class="hint">复习出题会优先使用这里的知识点。</p></div>' +
          '<div class="field"><label for="qEditNote">我的备注</label><textarea class="textarea textarea--short" id="qEditNote" placeholder="记下当时的错误原因或老师讲评">' + e(q.note || '') + '</textarea></div>' +
        '</form>',
      footer: '<button type="button" class="btn btn--ghost" data-action="close-modal">取消</button>' +
        '<button type="submit" form="editQuestionForm" class="btn btn--primary">保存</button>',
      onMount: function (root) {
        root.querySelector('#editQuestionForm').addEventListener('submit', async function (event) {
          event.preventDefault();
          const points = Array.from(new Set(String(root.querySelector('#qEditKps').value || '')
            .split(/[、,，;；\n]+/).map(function (s) { return s.trim(); }).filter(Boolean))).slice(0, 20);
          const note = String(root.querySelector('#qEditNote').value || '').trim().slice(0, 3000);
          const patch = { note: note, tags: points };
          if (q.analysis) patch.analysis = Object.assign({}, q.analysis, { knowledgePoints: points });
          try {
            await LR.db.updateQuestion(id, patch);
            App.closeModal();
            App.toast('错题信息已更新', 'success');
            App.render();
            openQuestionModal(id);
          } catch (err) {
            App.toast('保存失败：' + err.message, 'error');
          }
        });
      }
    });
  }
  actions['edit-question'] = function (el) { openEditQuestion(el.getAttribute('data-id')); };

  /* ----------------------------- mastery/delete -------------------------- */

  actions['toggle-mastered'] = async function (el) {
    const id = el.getAttribute('data-id');
    const q = LR.db.question(id);
    if (!q) return;
    try {
      await LR.db.updateQuestion(id, { mastered: !q.mastered });
      App.toast(q.mastered ? '已移回待复习' : '已标记为掌握', 'success');
      App.render();
      refreshQuestionModal(id);
    } catch (err) {
      App.toast('更新失败：' + err.message, 'error');
    }
  };

  actions['delete-question'] = async function (el) {
    const id = el.getAttribute('data-id');
    const q = LR.db.question(id);
    if (!q) return;
    const ok = await App.confirm({
      title: '删除这道错题？',
      message: '题目图片、解析和知识点会一起删除，且无法撤销。',
      confirmLabel: '删除',
      danger: true
    });
    if (!ok) return;
    const hide = App.showBusy('正在删除', '');
    try {
      await LR.db.deleteQuestion(id);
      activeQuestionId = null;
      hide();
      App.closeModal();
      App.render();
      App.toast('错题已删除', 'success');
    } catch (err) {
      hide();
      App.toast('删除失败：' + err.message, 'error');
    }
  };

  /* ---------------------------- notebook menu ---------------------------- */

  function openNotebookMenu(id) {
    const notebook = LR.db.notebook(id);
    if (!notebook) return;
    const stats = LR.db.notebookStats(id);
    App.openBasicModal({
      title: '管理错题本',
      eyebrow: 'NOTEBOOK / MANAGE',
      body:
        '<div class="stack-sm">' +
          '<button type="button" class="btn btn--ghost btn--block" id="renameNotebookBtn" style="justify-content:flex-start">' + icon('edit') + '重命名错题本</button>' +
          '<button type="button" class="btn btn--ghost btn--block" id="deleteNotebookBtn" style="justify-content:flex-start">' + icon('trash') + '删除错题本</button>' +
        '</div>' +
        '<div class="divider"></div>' +
        '<div class="backup-summary">' +
          '<div class="backup-metric"><strong>' + stats.total + '</strong><span>道错题</span></div>' +
          '<div class="backup-metric"><strong>' + stats.unmastered + '</strong><span>待复习</span></div>' +
          '<div class="backup-metric"><strong>' + stats.knowledge.length + '</strong><span>个知识点</span></div>' +
        '</div>' +
        '<p class="modal-note">删除错题本会同时删除其中所有错题和关联复习记录，无法恢复。</p>',
      footer: '<button type="button" class="btn btn--ghost btn--grow" data-action="close-modal">关闭</button>',
      onMount: function (root) {
        root.querySelector('#renameNotebookBtn').addEventListener('click', function () { openRenameNotebook(id); });
        root.querySelector('#deleteNotebookBtn').addEventListener('click', function () { deleteNotebook(id); });
      }
    });
  }
  actions['notebook-menu'] = function (el) { openNotebookMenu(el.getAttribute('data-id')); };

  function openRenameNotebook(id) {
    const notebook = LR.db.notebook(id);
    if (!notebook) return;
    App.openBasicModal({
      title: '重命名错题本',
      eyebrow: 'RENAME',
      center: true,
      body:
        '<form id="renameNotebookForm"><div class="field"><label for="renameNotebookInput">错题本名称</label><input class="input" id="renameNotebookInput" maxlength="40" value="' + attr(notebook.name) + '" autofocus></div></form>',
      footer: '<button type="button" class="btn btn--ghost" data-action="close-modal">取消</button><button type="submit" class="btn btn--primary" form="renameNotebookForm">保存</button>',
      onMount: function (root) {
        root.querySelector('#renameNotebookForm').addEventListener('submit', async function (event) {
          event.preventDefault();
          try {
            await LR.db.updateNotebook(id, { name: root.querySelector('#renameNotebookInput').value });
            App.closeModal();
            App.render();
            App.toast('名称已更新', 'success');
          } catch (err) {
            App.toast(err.message, 'error');
          }
        });
      }
    });
  }

  async function deleteNotebook(id) {
    const notebook = LR.db.notebook(id);
    if (!notebook) return;
    const stats = LR.db.notebookStats(id);
    const ok = await App.confirm({
      title: '删除「' + notebook.name + '」？',
      message: '这会删除 ' + stats.total + ' 道错题、相关复习记录和题目图片，且无法恢复。',
      hint: '建议先在设置中导出 ZIP 备份。',
      confirmLabel: '删除错题本',
      danger: true
    });
    if (!ok) return;
    const hide = App.showBusy('正在删除错题本', '');
    try {
      await LR.db.deleteNotebook(id);
      hide();
      App.closeModal();
      App.ui.notebookFilter = 'all';
      App.toast('错题本已删除', 'success');
      App.navigate('#/notebooks');
    } catch (err) {
      hide();
      App.toast('删除失败：' + err.message, 'error');
    }
  }

  App.openNotebookMenu = openNotebookMenu;
  App.analysisBusy = analysisBusy;
})();
