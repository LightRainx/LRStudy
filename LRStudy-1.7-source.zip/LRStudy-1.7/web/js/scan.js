/* LRStudy v1.7 — camera capture, automatic question framing, upload */
(function () {
  'use strict';

  const LR = window.LR;
  const App = window.App;
  const e = App.e;
  const icon = App.icon;
  let scan = null;

  function updateHeader(title, eyebrow) {
    if (!scan || !scan.root) return;
    const t = scan.root.querySelector('.modal-title');
    const y = scan.root.querySelector('.modal-eyebrow');
    if (t) t.textContent = title;
    if (y) y.textContent = eyebrow;
  }

  function revokeNothing() {
    // Page previews use data URLs; object URLs from file decoding are cleaned by util.js.
  }

  function openScanModal(notebookId) {
    const notebook = LR.db.notebook(notebookId);
    if (!notebook) {
      App.toast('请先打开一个错题本', 'error');
      return;
    }
    scan = {
      notebookId: notebookId,
      notebookName: notebook.name,
      step: 'intro',
      pageCanvas: null,
      pageURL: '',
      analysisCanvas: null,
      regions: [],
      autoRemove: false,
      drawMode: false,
      drawStart: null,
      error: '',
      busy: false,
      token: LR.uid('scan')
    };
    App.openBasicModal({
      title: '添加错题',
      eyebrow: 'CAPTURE / 01',
      size: 'full',
      body: '<div id="scanBody"></div>',
      footer: '<div id="scanFoot"></div>',
      onMount: function (root) {
        if (!scan) return;
        scan.root = root;
        scan.body = root.querySelector('.modal-body');
        scan.foot = root.querySelector('.modal-foot');
        scan.foot.style.display = 'none';
        renderScanStep();
      },
      onClose: function () {
        scan = null;
      }
    });
  }

  function renderScanStep() {
    if (!scan || !scan.root || !scan.root.isConnected) return;
    scan.body.scrollTop = 0;
    if (scan.step === 'intro') renderIntro();
    else if (scan.step === 'loading') renderLoading();
    else if (scan.step === 'select') renderSelect();
  }

  function renderIntro() {
    if (!scan) return;
    updateHeader('添加错题', 'CAPTURE / 01');
    scan.foot.style.display = 'none';
    scan.body.innerHTML =
      '<div class="scan-intro">' +
        (scan.error ? '<div class="notice notice--solid">' + icon('warning') + '<span>' + e(scan.error) + '</span></div>' : '') +
        '<div class="scan-source-grid">' +
          '<button type="button" class="scan-source" data-source="camera">' +
            '<span class="scan-source-icon">' + icon('camera') + '</span>' +
            '<span class="scan-source-copy"><strong>拍一张照片</strong><span>调用手机相机</span></span>' +
          '</button>' +
          '<button type="button" class="scan-source" data-source="gallery">' +
            '<span class="scan-source-icon">' + icon('image') + '</span>' +
            '<span class="scan-source-copy"><strong>从相册选择</strong><span>支持 JPG / PNG</span></span>' +
          '</button>' +
        '</div>' +
        '<div class="scan-tips">' +
          '<h4>拍摄小提示</h4>' +
          '<ol>' +
            '<li>尽量把纸张放平，四边都拍进画面。</li>' +
            '<li>保持光线均匀，避免手影遮住题目。</li>' +
            '<li>一页有多道题也可以，LRStudy 会自动框选，你再选择要上传的题。</li>' +
          '</ol>' +
        '</div>' +
        '<div class="notice">' + icon('info') + '<span>照片只在本机处理。自动框选基于版式留白，如果某道题没有框准，可以在下一步手动补框或整页上传。</span></div>' +
      '</div>';
    scan.body.querySelectorAll('[data-source]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (!scan) return;
        const source = btn.getAttribute('data-source');
        App.pickFiles({ accept: 'image/*', capture: source === 'camera' ? 'environment' : undefined }).then(function (files) {
          if (files && files[0]) processPageFile(files[0]);
        });
      });
    });
  }

  function renderLoading() {
    if (!scan) return;
    updateHeader('正在框选题目', 'CAPTURE / 02');
    scan.foot.style.display = 'none';
    scan.body.innerHTML =
      '<div class="scan-loading">' +
        '<div class="scan-skeleton" aria-hidden="true"></div>' +
        '<h3>正在阅读这一页…</h3>' +
        '<p>识别题目之间的留白并自动框选</p>' +
        '<span class="spinner" aria-hidden="true"></span>' +
      '</div>';
  }

  async function processPageFile(file) {
    if (!scan) return;
    if (!file.type || !/^image\//.test(file.type)) {
      scan.error = '请选择图片文件';
      renderIntro();
      return;
    }
    const token = scan.token;
    scan.error = '';
    scan.step = 'loading';
    renderScanStep();
    await LR.sleep(80);
    try {
      const pageCanvas = await LR.imageFileToCanvas(file, 2600);
      if (!scan || scan.token !== token) return;
      scan.pageCanvas = pageCanvas;
      scan.pageURL = LR.canvasToDataURL(pageCanvas, 'image/jpeg', 0.92);
      const analysisCanvas = LR.pageCanvasForAnalysis(pageCanvas, 1080);
      scan.analysisCanvas = analysisCanvas;
      await LR.sleep(90);
      let ocrResult = null;
      try {
        if (LR.ocr && await LR.ocr.isReady()) {
          ocrResult = await LR.ocr.recognizeCanvas(pageCanvas);
        }
      } catch (ocrError) {
        console.warn('OCR 识别失败，回退版式分割', ocrError);
      }
      if (!scan || scan.token !== token) return;

      let regions = [];
      let ocrUsed = false;
      if (ocrResult && ocrResult.lines.length) {
        const ocrRegions = LR.ocr.regionsFromTexts(ocrResult.lines);
        if (ocrRegions.length) {
          regions = ocrRegions;
          ocrUsed = true;
        }
      }
      if (!regions.length) regions = LR.segmentQuestions(analysisCanvas);
      const fallback = !regions.length;
      const visionConfigured = !!LR.ai.config.visionModel;
      if (fallback) {
        regions = [{ x: 0.012, y: 0.012, w: 0.976, h: 0.976 }];
      }
      if (!scan || scan.token !== token) return;
      scan.regions = regions.map(function (region) {
        return {
          x: region.x,
          y: region.y,
          w: region.w,
          h: region.h,
          ocrText: region.ocrText || '',
          // If the whole page is only a fallback and no vision model is
          // configured, do not pre-select it as one giant question.
          selected: fallback ? visionConfigured : true
        };
      });
      if (ocrResult && !ocrUsed) LR.ocr.assignTexts(scan.regions, ocrResult.lines);
      scan.fallback = fallback;
      scan.noVisionFallback = fallback && !visionConfigured;
      scan.ocrUsed = ocrUsed;
      scan.ocrResult = ocrResult;
      scan.step = 'select';
      renderScanStep();
    } catch (err) {
      console.error(err);
      if (!scan || scan.token !== token) return;
      scan.step = 'intro';
      scan.error = '照片处理失败：' + (err.message || '请换一张照片重试');
      renderScanStep();
    }
  }

  function regionMarkup(region, index, pageW, pageH) {
    const x = region.x * pageW;
    const y = region.y * pageH;
    const w = region.w * pageW;
    const h = region.h * pageH;
    const labelSize = Math.max(30, Math.round(pageW * 0.026));
    const labelX = Math.max(2, Math.min(pageW - labelSize - 2, x - labelSize / 2));
    const labelY = Math.max(2, Math.min(pageH - labelSize - 2, y - labelSize / 2));
    const selected = region.selected;
    return '<g class="scan-region ' + (selected ? 'scan-region--selected' : 'scan-region--unselected') + '" data-region-index="' + index + '" role="button" tabindex="0" aria-label="第 ' + (index + 1) + ' 题' + (selected ? '，已选中' : '，未选中') + '">' +
      '<rect class="scan-region-hit" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '"></rect>' +
      '<rect class="scan-region-halo" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '"></rect>' +
      '<rect class="scan-region-outline" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '"></rect>' +
      '<g transform="translate(' + labelX + ',' + labelY + ')">' +
        '<rect class="scan-region-index-bg" x="0" y="0" width="' + labelSize + '" height="' + labelSize + '" rx="' + Math.round(labelSize * 0.18) + '"></rect>' +
        '<text class="scan-region-index" x="' + (labelSize / 2) + '" y="' + (labelSize / 2 + 1) + '" style="font-size:' + Math.round(labelSize * 0.48) + 'px">' + (index + 1) + '</text>' +
      '</g>' +
    '</g>';
  }

  function selectedCount() {
    return scan ? scan.regions.filter(function (r) { return r.selected; }).length : 0;
  }

  function renderSelect() {
    if (!scan) return;
    updateHeader('选择要收录的题目', 'CAPTURE / 03');
    const width = scan.pageCanvas.width;
    const height = scan.pageCanvas.height;
    const ratio = width / height;
    const selected = selectedCount();
    const drawMode = scan.drawMode;
    scan.foot.style.display = 'flex';
    scan.body.innerHTML =
      '<div class="scan-caption">' +
        '<div class="scan-caption-main">' +
          '<span class="badge badge--filled" id="scanSelectedBadge">已选 ' + selected + '</span>' +
          '<span class="scan-caption-sub">' + (scan.ocrUsed ? 'OCR 识别到 ' + scan.regions.length + ' 道题' : (scan.fallback ? (scan.noVisionFallback ? '未识别到分隔 · 请手动选择' : '未识别到分隔 · 已框选整页') : '共框选 ' + scan.regions.length + ' 处')) + '</span>' +
        '</div>' +
        '<div class="scan-caption-actions">' +
          '<button type="button" class="btn btn--small btn--ghost" data-scan-action="all">全选</button>' +
          '<button type="button" class="btn btn--small btn--ghost" data-scan-action="none">清空</button>' +
        '</div>' +
      '</div>' +
      '<div class="scan-draw-bar">' +
        '<button type="button" class="btn btn--small ' + (drawMode ? 'btn--primary' : 'btn--ghost') + '" data-scan-action="draw">' + icon('plus') + (drawMode ? '退出画框' : '手动框选') + '</button>' +
        '<span>' + (drawMode ? '在照片上按住并拖动，补画题目区域' : '自动框选不完整时，可手动补画题目') + '</span>' +
      '</div>' +
      '<div class="scan-stage' + (drawMode ? ' scan-draw-mode' : '') + '">' +
        '<div class="scan-image-box" style="aspect-ratio:' + width + '/' + height + ';width:min(100%,calc(62dvh * ' + ratio.toFixed(5) + '));">' +
          '<img src="' + scan.pageURL + '" alt="待框选的试卷照片">' +
          '<svg class="scan-overlay" viewBox="0 0 ' + width + ' ' + height + '" preserveAspectRatio="none" aria-label="题目框选区域">' +
            scan.regions.map(function (region, i) { return regionMarkup(region, i, width, height); }).join('') +
            '<rect class="scan-draw-preview" id="scanDrawPreview" x="0" y="0" width="0" height="0" style="display:none"></rect>' +
          '</svg>' +
        '</div>' +
      '</div>' +
      (scan.noVisionFallback ? '<div class="notice" style="margin:12px 16px 0">' + icon('info') + '<span>未配置识图模型，没有默认勾选整页。请点按照片中的整页框，或用手动画框选中具体题目后再上传。</span></div>' : '') +
      '<div class="scan-controls">' +
        '<div class="scan-options">' +
          '<div class="scan-option">' +
            '<div class="scan-option-copy"><strong>消除彩色笔迹</strong><span>默认关闭；开启后只移除高饱和红、蓝、绿笔迹，尽量保留纸张底色</span></div>' +
            '<button type="button" class="switch" role="switch" aria-checked="' + (scan.autoRemove ? 'true' : 'false') + '" data-scan-toggle="ink" aria-label="消除彩色笔迹"></button>' +
          '</div>' +
        '</div>' +
        '<div class="scan-action-row">' +
          '<button type="button" class="btn btn--ghost btn--small" data-scan-action="whole">整页作为一题</button>' +
          '<button type="button" class="btn btn--ghost btn--small" data-scan-action="reset">重选照片</button>' +
        '</div>' +
        '<p class="scan-hint">' + (drawMode ? '在照片上按住并拖动，画出要收录的题目区域。' : '点按框内区域可以选中或取消。上传后会为每一道选中的题保留清晰图片。') + '</p>' +
      '</div>';

    scan.foot.innerHTML =
      '<div class="modal-foot-note" id="scanFootNote">将上传 ' + selected + ' 道题 · 归入「' + e(scan.notebookName) + '」</div>' +
      '<button type="button" class="btn btn--primary" data-scan-action="upload" id="scanUploadButton"' + (selected ? '' : ' disabled') + '>' + icon('upload') + '上传' + (selected ? ' ' + selected + ' 题' : '') + '</button>';

    bindSelectEvents();
  }

  function updateSelectionUI() {
    if (!scan || !scan.root) return;
    const svg = scan.root.querySelector('.scan-overlay');
    if (!svg) return;
    scan.regions.forEach(function (region, i) {
      const group = svg.querySelector('[data-region-index="' + i + '"]');
      if (!group) return;
      group.classList.toggle('scan-region--selected', !!region.selected);
      group.classList.toggle('scan-region--unselected', !region.selected);
      group.setAttribute('aria-label', '第 ' + (i + 1) + ' 题' + (region.selected ? '，已选中' : '，未选中'));
    });
    const selected = selectedCount();
    const badge = scan.root.querySelector('#scanSelectedBadge');
    if (badge) badge.textContent = '已选 ' + selected;
    const footNote = scan.root.querySelector('#scanFootNote');
    if (footNote) footNote.textContent = '将上传 ' + selected + ' 道题 · 归入「' + scan.notebookName + '」';
    const upload = scan.root.querySelector('#scanUploadButton');
    if (upload) {
      upload.disabled = selected === 0;
      upload.innerHTML = icon('upload') + '上传' + (selected ? ' ' + selected + ' 题' : '');
    }
  }

  function bindSelectEvents() {
    if (!scan || !scan.root) return;
    const stage = scan.root.querySelector('.scan-stage');
    const svg = scan.root.querySelector('.scan-overlay');
    if (!svg) return;

    svg.addEventListener('click', function (event) {
      if (!scan || scan.drawMode) return;
      const group = event.target.closest('[data-region-index]');
      if (!group) return;
      const index = Number(group.getAttribute('data-region-index'));
      if (!scan.regions[index]) return;
      scan.regions[index].selected = !scan.regions[index].selected;
      updateSelectionUI();
    });

    svg.addEventListener('keydown', function (event) {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      const group = event.target.closest('[data-region-index]');
      if (!group) return;
      event.preventDefault();
      const index = Number(group.getAttribute('data-region-index'));
      if (!scan.regions[index]) return;
      scan.regions[index].selected = !scan.regions[index].selected;
      updateSelectionUI();
    });

    scan.root.querySelectorAll('[data-scan-action]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (!scan) return;
        const action = btn.getAttribute('data-scan-action');
        if (action === 'all') {
          scan.regions.forEach(function (r) { r.selected = true; });
          updateSelectionUI();
        } else if (action === 'none') {
          scan.regions.forEach(function (r) { r.selected = false; });
          updateSelectionUI();
        } else if (action === 'draw') {
          scan.drawMode = !scan.drawMode;
          renderSelect();
          if (scan.drawMode) {
            const body = scan.body;
            if (body) {
              body.scrollTo({ top: 0, behavior: 'smooth' });
            }
          }
        } else if (action === 'whole') {
          scan.regions = [{ x: 0.008, y: 0.008, w: 0.984, h: 0.984, selected: true }];
          scan.drawMode = false;
          scan.fallback = true;
          renderSelect();
        } else if (action === 'reset') {
          scan.step = 'intro';
          scan.pageCanvas = null;
          scan.pageURL = '';
          scan.regions = [];
          scan.drawMode = false;
          renderScanStep();
        } else if (action === 'upload') {
          uploadSelectedRegions();
        }
      });
    });

    const inkToggle = scan.root.querySelector('[data-scan-toggle="ink"]');
    if (inkToggle) {
      inkToggle.addEventListener('click', function () {
        if (!scan) return;
        scan.autoRemove = !scan.autoRemove;
        inkToggle.setAttribute('aria-checked', scan.autoRemove ? 'true' : 'false');
      });
    }

    // Manual drawing with pointer events.
    let activePointer = null;
    svg.addEventListener('pointerdown', function (event) {
      if (!scan || !scan.drawMode || event.button > 0) return;
      event.preventDefault();
      event.stopPropagation();
      const rect = svg.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const point = {
        x: LR.clamp((event.clientX - rect.left) / rect.width, 0, 1) * scan.pageCanvas.width,
        y: LR.clamp((event.clientY - rect.top) / rect.height, 0, 1) * scan.pageCanvas.height
      };
      scan.drawStart = point;
      activePointer = event.pointerId;
      try { svg.setPointerCapture(activePointer); } catch (_) {}
      const preview = svg.querySelector('#scanDrawPreview');
      if (preview) {
        preview.style.display = 'block';
        preview.setAttribute('x', point.x);
        preview.setAttribute('y', point.y);
        preview.setAttribute('width', 0);
        preview.setAttribute('height', 0);
      }
    });

    svg.addEventListener('pointermove', function (event) {
      if (!scan || !scan.drawMode || !scan.drawStart || activePointer !== event.pointerId) return;
      event.preventDefault();
      const rect = svg.getBoundingClientRect();
      const point = {
        x: LR.clamp((event.clientX - rect.left) / rect.width, 0, 1) * scan.pageCanvas.width,
        y: LR.clamp((event.clientY - rect.top) / rect.height, 0, 1) * scan.pageCanvas.height
      };
      const preview = svg.querySelector('#scanDrawPreview');
      if (!preview) return;
      const x = Math.min(scan.drawStart.x, point.x);
      const y = Math.min(scan.drawStart.y, point.y);
      preview.setAttribute('x', x);
      preview.setAttribute('y', y);
      preview.setAttribute('width', Math.abs(point.x - scan.drawStart.x));
      preview.setAttribute('height', Math.abs(point.y - scan.drawStart.y));
    });

    function endDraw(event) {
      if (!scan || !scan.drawStart || activePointer !== event.pointerId) return;
      event.preventDefault();
      const rect = svg.getBoundingClientRect();
      const point = {
        x: LR.clamp((event.clientX - rect.left) / rect.width, 0, 1) * scan.pageCanvas.width,
        y: LR.clamp((event.clientY - rect.top) / rect.height, 0, 1) * scan.pageCanvas.height
      };
      const x = Math.min(scan.drawStart.x, point.x);
      const y = Math.min(scan.drawStart.y, point.y);
      const w = Math.abs(point.x - scan.drawStart.x);
      const h = Math.abs(point.y - scan.drawStart.y);
      scan.drawStart = null;
      activePointer = null;
      try { svg.releasePointerCapture(event.pointerId); } catch (_) {}
      if (w < scan.pageCanvas.width * 0.035 || h < scan.pageCanvas.height * 0.018) {
        App.toast('框选区域太小，请重新拖动', 'error');
        const preview = svg.querySelector('#scanDrawPreview');
        if (preview) preview.style.display = 'none';
        return;
      }
      scan.regions.push({
        x: x / scan.pageCanvas.width,
        y: y / scan.pageCanvas.height,
        w: w / scan.pageCanvas.width,
        h: h / scan.pageCanvas.height,
        selected: true
      });
      scan.regions.sort(function (a, b) { return a.y - b.y || a.x - b.x; });
      scan.drawMode = false;
      renderSelect();
      App.toast('已补画一个题目区域', 'success');
    }

    svg.addEventListener('pointerup', endDraw);
    svg.addEventListener('pointercancel', function (event) {
      if (!scan || !scan.drawStart) return;
      scan.drawStart = null;
      activePointer = null;
      const preview = svg.querySelector('#scanDrawPreview');
      if (preview) preview.style.display = 'none';
    });

    void stage;
    void revokeNothing;
  }

  async function uploadSelectedRegions() {
    if (!scan || scan.busy) return;
    const selected = scan.regions
      .map(function (region, index) { return { region: region, index: index }; })
      .filter(function (item) { return item.region.selected; })
      .map(function (item) { return item.region; })
      .sort(function (a, b) { return a.y - b.y || a.x - b.x; });
    if (!selected.length) {
      App.toast('请先选择至少一道题', 'error');
      return;
    }
    scan.busy = true;
    const token = scan.token;
    const notebookId = scan.notebookId;
    const notebookName = scan.notebookName;
    const autoRemove = scan.autoRemove;
    const pageCanvas = scan.pageCanvas;
    const hideBusy = App.showBusy('正在收录错题', '正在裁切所选题目并保存到本地…');
    const created = [];
    const errors = [];
    // Give the top-most question the newest timestamp, so the archived list
    // preserves the original top-to-bottom reading order.
    const baseTime = Date.now() + selected.length;
    try {
      for (let selectedIndex = 0; selectedIndex < selected.length; selectedIndex++) {
        const region = selected[selectedIndex];
        if (!scan || scan.token !== token) break;
        const cropped = LR.cropPageRegion(pageCanvas, region, { padding: 0.01, maxSide: 1800 });
        if (autoRemove) {
          try { LR.removeColoredInk(cropped); } catch (err) { console.warn('去色失败', err); }
        }
        const blob = await LR.canvasToBlob(cropped, 'image/jpeg', 0.88);
        const record = await LR.db.saveImage(blob);
        const ocrText = scan.ocrResult && LR.ocr
          ? LR.ocr.textForRegion(region, scan.ocrResult.lines).slice(0, 6000)
          : '';
        const question = await LR.db.addQuestion(notebookId, {
          imageId: record.id,
          imageWidth: cropped.width,
          imageHeight: cropped.height,
          source: 'photo',
          contentText: ocrText,
          ocrSource: ocrText ? 'rapidocr' : '',
          title: '拍照错题',
          createdAt: new Date(baseTime - selectedIndex).toISOString()
        });
        created.push(question);
      }
      if (!scan || scan.token !== token) return;
      App.closeModal();
      App.ui.notebookFilter = 'all';
      App.render();
      if (created.length) {
        App.toast('已收录 ' + created.length + ' 道错题到「' + notebookName + '」', 'success');
        const settings = LR.db.state.settings.ai;
        if (settings.autoAnalyze && LR.ai.isConfigured()) {
          App.autoAnalyzeQuestions(created.map(function (q) { return q.id; }), { silent: false });
        }
      }
      if (errors.length) App.toast(errors[0], 'error');
    } catch (err) {
      console.error(err);
      if (!scan || scan.token !== token) return;
      scan.busy = false;
      App.toast('上传失败：' + (err.message || '请重试'), 'error');
      return;
    } finally {
      hideBusy();
    }
  }

  App.openScanModal = openScanModal;
  App.actions['capture'] = function (el) {
    let notebookId = el.getAttribute('data-notebook');
    if (!notebookId && App.route() && App.route().page === 'notebook') notebookId = App.route().notebookId;
    if (!notebookId) {
      App.toast('请先打开一个错题本', 'error');
      return;
    }
    openScanModal(notebookId);
  };
})();
