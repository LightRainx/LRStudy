/* LRStudy v1.7 — ZIP backup, WebDAV upload and restore */
(function () {
  'use strict';

  const LR = window.LR;
  const BACKUP_FORMAT = 1;

  const nativeDavPending = new Map();
  let nativeDavSeq = 0;

  function bytesToBase64(bytes) {
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return btoa(binary);
  }

  function base64ToBytes(base64) {
    const binary = atob(base64 || '');
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function hasNativeWebDAV() {
    return !!(window.LRNative && typeof window.LRNative.davRequest === 'function');
  }

  function installNativeDavCallbacks() {
    if (window.__lrNativeDavInstalled) return;
    window.__lrNativeDavInstalled = true;
    window.__lrNativeDavStart = function (requestId, status, contentType) {
      const pending = nativeDavPending.get(requestId);
      if (!pending) return;
      pending.status = Number(status) || 0;
      pending.contentType = String(contentType || '');
      pending.started = true;
    };
    window.__lrNativeDavChunk = function (requestId, base64) {
      const pending = nativeDavPending.get(requestId);
      if (!pending) return;
      pending.chunks.push(base64ToBytes(base64));
    };
    window.__lrNativeDavDone = function (requestId) {
      const pending = nativeDavPending.get(requestId);
      if (!pending) return;
      nativeDavPending.delete(requestId);
      clearTimeout(pending.timer);
      let total = 0;
      pending.chunks.forEach(function (chunk) { total += chunk.length; });
      const bytes = new Uint8Array(total);
      let offset = 0;
      pending.chunks.forEach(function (chunk) {
        bytes.set(chunk, offset);
        offset += chunk.length;
      });
      pending.resolve({
        status: pending.status,
        ok: pending.status >= 200 && pending.status < 300,
        contentType: pending.contentType,
        bytes: bytes
      });
    };
    window.__lrNativeDavFail = function (requestId, message) {
      const pending = nativeDavPending.get(requestId);
      if (!pending) return;
      nativeDavPending.delete(requestId);
      clearTimeout(pending.timer);
      pending.reject(new Error(String(message || 'WebDAV 原生通道请求失败')));
    };
  }
  installNativeDavCallbacks();

  async function bodyToBase64(body) {
    if (body == null) return '';
    if (typeof body === 'string') return bytesToBase64(new TextEncoder().encode(body));
    if (body instanceof Blob) {
      const dataURL = await LR.readBlobAsDataURL(body);
      return String(dataURL).slice(String(dataURL).indexOf(',') + 1);
    }
    if (body instanceof ArrayBuffer) return bytesToBase64(new Uint8Array(body));
    if (body instanceof Uint8Array) return bytesToBase64(body);
    return bytesToBase64(new TextEncoder().encode(String(body)));
  }

  async function nativeDavRequest(method, url, headers, body, timeoutMs) {
    installNativeDavCallbacks();
    const requestId = 'dav-' + Date.now().toString(36) + '-' + (++nativeDavSeq);
    const bodyBase64 = await bodyToBase64(body);
    const timeout = timeoutMs || 90000;
    return new Promise(function (resolve, reject) {
      const pending = {
        resolve: resolve,
        reject: reject,
        status: 0,
        contentType: '',
        chunks: [],
        started: false,
        timer: null
      };
      pending.timer = setTimeout(function () {
        nativeDavPending.delete(requestId);
        reject(new Error('WebDAV 请求超时'));
      }, timeout + 15000);
      nativeDavPending.set(requestId, pending);
      try {
        window.LRNative.davRequest(requestId, method, url, JSON.stringify(headers || {}),
            bodyBase64, timeout);
      } catch (err) {
        nativeDavPending.delete(requestId);
        clearTimeout(pending.timer);
        reject(err);
      }
    });
  }

  // Unified request: Android uses its native transport (no CORS), browsers use
  // fetch and therefore still respect the WebDAV server's CORS policy.
  async function rawDavRequest(method, url, headers, body, timeout) {
    if (hasNativeWebDAV()) {
      return await nativeDavRequest(method, url, headers, body, timeout);
    }
    let response;
    try {
      const options = { method: method, headers: headers };
      if (body != null) options.body = body;
      response = await requestWithTimeout(url, options, timeout);
    } catch (err) {
      throw new Error(friendlyFetchError(err, '请求'));
    }
    let bytes = new Uint8Array(0);
    try {
      const buffer = await response.arrayBuffer();
      bytes = new Uint8Array(buffer);
    } catch (_) {}
    return {
      status: response.status,
      ok: response.ok,
      contentType: response.headers.get('content-type') || '',
      bytes: bytes
    };
  }

  function extensionForMime(mime) {
    const type = String(mime || '').toLowerCase();
    if (type.indexOf('png') >= 0) return 'png';
    if (type.indexOf('webp') >= 0) return 'webp';
    if (type.indexOf('gif') >= 0) return 'gif';
    return 'jpg';
  }

  function mimeForName(name) {
    const ext = String(name).split('.').pop().toLowerCase();
    if (ext === 'png') return 'image/png';
    if (ext === 'webp') return 'image/webp';
    if (ext === 'gif') return 'image/gif';
    return 'image/jpeg';
  }

  function stripSecrets(data) {
    data.settings = data.settings || {};
    data.settings.ai = data.settings.ai || {};
    data.settings.webdav = data.settings.webdav || {};
    data.settings.ai.apiKey = '';
    data.settings.webdav.password = '';
    return data;
  }

  function buildDataJSON(includeSecrets) {
    const state = LR.clone(LR.db.state);
    // Runtime-only data should not leak into backups.
    delete state.__transient;
    if (!includeSecrets) stripSecrets(state);
    return state;
  }

  function buildReadme(stats, includeSecrets) {
    return [
      'LRStudy ' + LR.APP_VERSION + ' 数据备份',
      '导出时间：' + new Date().toLocaleString('zh-CN'),
      '',
      '本压缩包包含：',
      '· data.json — 错题本、错题、AI 解析、复习记录、个人资料与设置',
      '· images/ — 原始错题图片与批改照片',
      '· manifest.json — 备份清单',
      '',
      '共 ' + stats.notebooks + ' 个错题本，' + stats.questions + ' 道错题，' + stats.sessions + ' 次复习记录，' + stats.images + ' 张图片。',
      includeSecrets
        ? '注意：本次备份包含 API Key 和 WebDAV 密码，请妥善保管。'
        : '本次备份未包含 API Key 和 WebDAV 密码。',
      '',
      '恢复方式：打开 LRStudy → 设置 → 备份与恢复 → 导入 ZIP。',
      'PDF 练习卷可在「复习」中随时重新导出。'
    ].join('\n');
  }

  async function buildBackup(options) {
    const opts = options || {};
    const includeSecrets = opts.includeSecrets !== false;
    const data = buildDataJSON(includeSecrets);
    const imageRecords = await LR.db.getAllImages();
    const manifestImages = [];
    const entries = [];
    let totalImageBytes = 0;

    imageRecords.forEach(function (record) {
      if (!record || !record.blob) return;
      const ext = extensionForMime(record.mime || record.blob.type);
      const file = 'images/' + record.id + '.' + ext;
      entries.push({ name: file, data: record.blob });
      manifestImages.push({
        id: record.id,
        file: file,
        mime: record.mime || record.blob.type || mimeForName(file),
        size: record.blob.size || 0
      });
      totalImageBytes += record.blob.size || 0;
    });

    const stats = {
      notebooks: data.notebooks.length,
      questions: data.questions.length,
      sessions: data.sessions.length,
      images: manifestImages.length,
      imageBytes: totalImageBytes,
      includeSecrets: includeSecrets,
      exportedAt: new Date().toISOString()
    };
    const manifest = {
      app: 'LRStudy',
      appVersion: 'v1.7',
      backupFormatVersion: BACKUP_FORMAT,
      createdAt: stats.exportedAt,
      counts: {
        notebooks: stats.notebooks,
        questions: stats.questions,
        sessions: stats.sessions,
        images: stats.images
      },
      includeSecrets: includeSecrets,
      images: manifestImages,
      files: ['manifest.json', 'data.json', 'README.txt'].concat(entries.map(function (e) { return e.name; }))
    };

    const zipEntries = [
      { name: 'manifest.json', data: JSON.stringify(manifest, null, 2) },
      { name: 'data.json', data: JSON.stringify(data, null, 2) },
      { name: 'README.txt', data: buildReadme(stats, includeSecrets) }
    ].concat(entries);

    const blob = await LR.zipCreate(zipEntries);
    return {
      blob: blob,
      filename: LR.BACKUP_FILENAME,
      stats: stats,
      manifest: manifest,
      data: data
    };
  }

  function webdavConfig() {
    const cfg = LR.db.state.settings.webdav || {};
    return {
      url: String(cfg.url || '').trim(),
      username: String(cfg.username || '').trim(),
      password: String(cfg.password || ''),
      lastBackupAt: cfg.lastBackupAt || null
    };
  }

  function normalizeBaseURL(url) {
    let base = String(url || '').trim();
    if (!base) throw new Error('请先填写 WebDAV 地址');
    if (!/^https?:\/\//i.test(base)) throw new Error('WebDAV 地址需要以 http:// 或 https:// 开头');
    if (/\/LRStudy\.zip$/i.test(base)) base = base.replace(/\/LRStudy\.zip$/i, '');
    return base.replace(/\/+$/, '');
  }

  function isAppFolderURL(base) {
    try {
      const path = new URL(base).pathname.replace(/\/+$/, '');
      return /(^|\/)LRStudy$/i.test(path);
    } catch (_) {
      return /(^|\/)LRStudy$/i.test(String(base).replace(/\/+$/, ''));
    }
  }

  function appendURLPath(base, segment) {
    const raw = String(base || '').replace(/\/+$/, '');
    try {
      const parsed = new URL(raw);
      parsed.pathname = parsed.pathname.replace(/\/+$/, '') + '/' + segment;
      return parsed.toString().replace(/\/+$/, '');
    } catch (_) {
      return raw + '/' + segment;
    }
  }

  // Nutstore (and some other WebDAV providers) reject PUT directly in the DAV
  // root with 404. Keep the backup in an app-owned LRStudy subdirectory instead.
  function appFolderURL(config) {
    const base = normalizeBaseURL(config.url);
    return isAppFolderURL(base) ? base : appendURLPath(base, 'LRStudy');
  }

  function legacyFileURL(config) {
    return appendURLPath(normalizeBaseURL(config.url), LR.BACKUP_FILENAME);
  }

  function fileURL(config) {
    return appendURLPath(appFolderURL(config), LR.BACKUP_FILENAME);
  }

  function propfindBody() {
    return '<?xml version="1.0" encoding="utf-8"?><d:propfind xmlns:d="DAV:"><d:prop><d:resourcetype/></d:prop></d:propfind>';
  }

  async function ensureAppFolder(config, auth) {
    const folder = appFolderURL(config) + '/';
    let response;
    try {
      response = await rawDavRequest('PROPFIND', folder, {
        'Authorization': auth,
        'Depth': '0',
        'Content-Type': 'application/xml; charset=utf-8'
      }, propfindBody(), 30000);
    } catch (err) {
      throw new Error(friendlyFetchError(err, '检查目录'));
    }
    if (response.status === 401) throw new Error('WebDAV 认证失败（401）：请检查用户名和应用密码');
    if (response.status === 403) throw new Error('WebDAV 拒绝访问（403）：请使用应用密码，而非登录密码');
    if (response.status === 404) {
      let created;
      try {
        created = await rawDavRequest('MKCOL', folder, { 'Authorization': auth }, null, 30000);
      } catch (err) {
        throw new Error(friendlyFetchError(err, '创建目录'));
      }
      if (created.status === 401) throw new Error('WebDAV 认证失败（401）：请检查用户名和应用密码');
      if (created.status === 403) throw new Error('WebDAV 拒绝创建目录（403）：请检查应用密码权限');
      if (![200, 201, 204, 405].includes(created.status)) {
        throw new Error('WebDAV 创建 LRStudy 目录失败（HTTP ' + created.status + '）');
      }
    } else if (!response.ok && response.status !== 207) {
      throw new Error('WebDAV 目录检查失败（HTTP ' + response.status + '）');
    }
    return folder;
  }

  function authHeader(config) {
    if (!config.username) throw new Error('请填写 WebDAV 用户名');
    if (!config.password) throw new Error('请填写 WebDAV 密码 / 应用密码');
    return 'Basic ' + LR.base64Basic(config.username, config.password);
  }

  function friendlyFetchError(err, action) {
    if (err && err.name === 'AbortError') return 'WebDAV ' + action + '超时，请检查网络或服务器地址';
    const message = err && err.message ? err.message : String(err);
    if (/Failed to fetch|NetworkError|Load failed/i.test(message)) {
      return '无法直连 WebDAV：可能是网络问题或服务器未开放浏览器跨域（CORS）。坚果云 WebDAV 在部分浏览器中会被跨域限制拦截，可先使用「导出 ZIP」，或换用支持 CORS 的 WebDAV 服务。原始错误：' + message;
    }
    return 'WebDAV ' + action + '失败：' + message;
  }

  async function requestWithTimeout(url, options, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(function () { controller.abort(); }, timeoutMs || 90000);
    try {
      return await fetch(url, Object.assign({}, options, { signal: controller.signal, cache: 'no-store' }));
    } finally {
      clearTimeout(timer);
    }
  }

  async function testWebDAV() {
    const cfg = webdavConfig();
    const url = normalizeBaseURL(cfg.url) + '/';
    const auth = authHeader(cfg);
    let response;
    try {
      response = await rawDavRequest('PROPFIND', url, {
        'Authorization': auth,
        'Depth': '0',
        'Content-Type': 'application/xml; charset=utf-8'
      }, propfindBody(), 30000);
    } catch (err) {
      throw new Error(friendlyFetchError(err, '连接'));
    }
    if (response.status === 401) throw new Error('WebDAV 认证失败（401）：请检查用户名和应用密码');
    if (response.status === 403) throw new Error('WebDAV 拒绝访问（403）：请使用应用密码，而非登录密码');
    if (response.status === 404) throw new Error('WebDAV 路径不存在（404）：请检查地址，坚果云通常为 https://dav.jianguoyun.com/dav/');
    if (!response.ok && response.status !== 207) {
      throw new Error('WebDAV 连接失败（HTTP ' + response.status + '）');
    }
    // Verify or create the dedicated folder now, so a successful test means
    // the later PUT has a real parent collection rather than the DAV root.
    let folder;
    try {
      folder = await ensureAppFolder(cfg, auth);
    } catch (err) {
      throw new Error(err.message || 'WebDAV 目录不可用');
    }
    return { status: response.status, url: url, folder: folder, fileUrl: fileURL(cfg) };
  }

  async function uploadToWebDAV(blob, options) {
    const cfg = webdavConfig();
    const auth = authHeader(cfg);
    await ensureAppFolder(cfg, auth);
    const url = fileURL(cfg);
    let response;
    try {
      response = await rawDavRequest('PUT', url, {
        'Authorization': auth,
        'Content-Type': 'application/zip'
      }, blob, (options && options.timeout) || 120000);
    } catch (err) {
      throw new Error(friendlyFetchError(err, '上传'));
    }
    if (response.status === 401) throw new Error('WebDAV 认证失败（401）：请检查用户名和应用密码');
    if (response.status === 403) throw new Error('WebDAV 拒绝访问（403）：请使用应用密码，而非登录密码');
    if (response.status === 404) throw new Error('WebDAV 上传路径不存在（404）：LRStudy/ 子目录不可写，请检查地址与权限');
    if (!response.ok && response.status !== 201 && response.status !== 204) {
      throw new Error('WebDAV 上传失败（HTTP ' + response.status + '）');
    }
    return { url: url, folder: appFolderURL(cfg), status: response.status, size: blob.size };
  }

  async function downloadFromWebDAV() {
    const cfg = webdavConfig();
    const auth = authHeader(cfg);
    const primary = fileURL(cfg);
    const legacy = legacyFileURL(cfg);
    const candidates = primary === legacy ? [primary] : [primary, legacy];
    let lastStatus = 0;
    for (let i = 0; i < candidates.length; i++) {
      const url = candidates[i];
      let response;
      try {
        response = await rawDavRequest('GET', url, { 'Authorization': auth }, null, 120000);
      } catch (err) {
        throw new Error(friendlyFetchError(err, '下载'));
      }
      lastStatus = response.status;
      if (response.status === 401) throw new Error('WebDAV 认证失败（401）');
      if (response.status === 404) continue;
      if (!response.ok) throw new Error('WebDAV 下载失败（HTTP ' + response.status + '）');
      return new Blob([response.bytes], { type: response.contentType || 'application/zip' });
    }
    if (lastStatus === 404) throw new Error('云端没有 LRStudy.zip 备份（已查找 LRStudy/ 子目录和根目录）');
  }

  async function restoreBackup(source) {
    let buffer;
    if (source instanceof Blob) buffer = await source.arrayBuffer();
    else if (source instanceof ArrayBuffer) buffer = source;
    else if (source && source.buffer instanceof ArrayBuffer) buffer = source.buffer;
    else throw new Error('无法读取备份文件');

    const zip = await LR.zipRead(buffer);
    const files = zip.files;
    const manifestBytes = files['manifest.json'];
    const dataBytes = files['data.json'];
    if (!manifestBytes || !dataBytes) throw new Error('不是 LRStudy 备份：缺少 manifest.json 或 data.json');
    let manifest;
    let data;
    try {
      manifest = JSON.parse(new TextDecoder('utf-8').decode(manifestBytes));
      data = JSON.parse(new TextDecoder('utf-8').decode(dataBytes));
    } catch (err) {
      throw new Error('备份内容损坏，无法读取 JSON：' + err.message);
    }
    if (!manifest || manifest.app !== 'LRStudy') throw new Error('不是 LRStudy 的备份文件');
    if (!data || !Array.isArray(data.notebooks) || !Array.isArray(data.questions)) {
      throw new Error('备份数据结构不完整');
    }
    const nextState = LR.normalizeState(data);

    // Preserve credentials when they were intentionally excluded.
    if (manifest.includeSecrets === false) {
      const current = LR.db.state;
      nextState.settings.ai.apiKey = current.settings.ai.apiKey;
      nextState.settings.webdav.password = current.settings.webdav.password;
    }

    const imageRecords = [];
    const manifestImages = Array.isArray(manifest.images) ? manifest.images : [];
    manifestImages.forEach(function (item) {
      if (!item || !item.id || !item.file || !files[item.file]) return;
      const bytes = files[item.file];
      const mime = item.mime || mimeForName(item.file);
      imageRecords.push({
        id: String(item.id),
        blob: new Blob([bytes], { type: mime }),
        mime: mime,
        createdAt: new Date().toISOString(),
        size: bytes.length
      });
    });
    // Also pick up image entries not listed in the manifest, as long as ids are parseable.
    zip.order.forEach(function (name) {
      if (!/^images\//.test(name)) return;
      const base = name.split('/').pop();
      const id = base.replace(/\.[^.]+$/, '');
      if (!id || imageRecords.some(function (r) { return r.id === id; })) return;
      const bytes = files[name];
      imageRecords.push({
        id: id,
        blob: new Blob([bytes], { type: mimeForName(name) }),
        mime: mimeForName(name),
        createdAt: new Date().toISOString(),
        size: bytes.length
      });
    });

    const referenced = new Set();
    nextState.questions.forEach(function (q) { if (q.imageId) referenced.add(q.imageId); });
    nextState.sessions.forEach(function (s) {
      (s.answerImageIds || []).forEach(function (id) { referenced.add(id); });
    });
    const availableIds = new Set(imageRecords.map(function (r) { return r.id; }));
    const missing = Array.from(referenced).filter(function (id) { return !availableIds.has(id); });

    await LR.db.replaceImages(imageRecords);
    await LR.db.replaceState(nextState);
    return {
      manifest: manifest,
      notebooks: nextState.notebooks.length,
      questions: nextState.questions.length,
      sessions: nextState.sessions.length,
      images: imageRecords.length,
      missingImages: missing.length
    };
  }

  LR.backup = {
    buildBackup: buildBackup,
    restoreBackup: restoreBackup,
    testWebDAV: testWebDAV,
    uploadToWebDAV: uploadToWebDAV,
    downloadFromWebDAV: downloadFromWebDAV,
    webdavConfig: webdavConfig,
    fileURL: fileURL,
    appFolderURL: appFolderURL,
    legacyFileURL: legacyFileURL
  };
})();
