/* LRStudy v1.7 — local RapidOCR/ONNX Runtime bridge for the scan flow */
(function () {
  'use strict';

  const LR = window.LR;
  let engine = null;
  let enginePromise = null;
  let blobUrls = [];

  function lib() {
    return window.LROcrLib || null;
  }

  function available() {
    const l = lib();
    return !!(l && l.Ocr && l.ort);
  }

  function fileRecord(record, key) {
    if (!record || !Array.isArray(record.files)) return null;
    return record.files.find(function (file) { return file && file.key === key && file.blob instanceof Blob; }) || null;
  }

  async function isReady() {
    if (!available()) return false;
    const settings = LR.db && LR.db.state && LR.db.state.settings.ocr;
    if (!settings || !settings.models) return false;
    if (!settings.models.rapidocr || !settings.models.rapidocr.enabled) return false;
    if (!settings.models.onnx || !settings.models.onnx.enabled) return false;
    try {
      const model = await LR.db.getOcrPackage('rapidocr');
      const runtime = await LR.db.getOcrPackage('onnx');
      return !!(fileRecord(model, 'det') && fileRecord(model, 'rec') && fileRecord(model, 'dict')
        && fileRecord(runtime, 'wasm'));
    } catch (_) {
      return false;
    }
  }

  function revokeUrls() {
    blobUrls.forEach(function (url) { try { URL.revokeObjectURL(url); } catch (_) {} });
    blobUrls = [];
  }

  async function createEngine() {
    if (engine) return engine;
    if (enginePromise) return enginePromise;
    if (!available()) throw new Error('OCR 运行时未加载');
    enginePromise = (async function () {
      const model = await LR.db.getOcrPackage('rapidocr');
      const runtime = await LR.db.getOcrPackage('onnx');
      const det = fileRecord(model, 'det');
      const rec = fileRecord(model, 'rec');
      const dict = fileRecord(model, 'dict');
      const wasm = fileRecord(runtime, 'wasm');
      if (!det || !rec || !dict || !wasm) throw new Error('OCR 组件尚未下载完整');
      revokeUrls();
      const detUrl = URL.createObjectURL(det.blob);
      const recUrl = URL.createObjectURL(rec.blob);
      const dictUrl = URL.createObjectURL(dict.blob);
      const wasmBlob = wasm.blob.type === 'application/wasm'
        ? wasm.blob
        : new Blob([wasm.blob], { type: 'application/wasm' });
      const wasmUrl = URL.createObjectURL(wasmBlob);
      blobUrls = [detUrl, recUrl, dictUrl, wasmUrl];
      const l = lib();
      l.ort.env.wasm.wasmPaths = { wasm: wasmUrl };
      l.ort.env.wasm.numThreads = 1;
      engine = await l.Ocr.create({
        models: {
          detectionPath: detUrl,
          recognitionPath: recUrl,
          dictionaryPath: dictUrl
        }
      });
      return engine;
    })();
    try {
      return await enginePromise;
    } catch (err) {
      engine = null;
      revokeUrls();
      throw err;
    } finally {
      enginePromise = null;
    }
  }

  function normalizeLines(result) {
    const width = Number(result && result.resizedImageWidth) || 1;
    const height = Number(result && result.resizedImageHeight) || 1;
    return (result && result.texts || []).map(function (item) {
      const box = Array.isArray(item.box) ? item.box : [];
      if (!box.length) return null;
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      box.forEach(function (point) {
        minX = Math.min(minX, Number(point[0]) || 0);
        minY = Math.min(minY, Number(point[1]) || 0);
        maxX = Math.max(maxX, Number(point[0]) || 0);
        maxY = Math.max(maxY, Number(point[1]) || 0);
      });
      const text = String(item.text || '').trim();
      if (!text) return null;
      return {
        text: text,
        confidence: Number(item.mean) || 0,
        x: LR.clamp(minX / width, 0, 1),
        y: LR.clamp(minY / height, 0, 1),
        w: LR.clamp((maxX - minX) / width, 0, 1),
        h: LR.clamp((maxY - minY) / height, 0, 1)
      };
    }).filter(Boolean).sort(function (a, b) { return a.y - b.y || a.x - b.x; });
  }

  async function recognizeCanvas(canvas) {
    const ocr = await createEngine();
    const source = LR.pageCanvasForAnalysis(canvas, 1600);
    const dataUrl = LR.canvasToDataURL(source, 'image/jpeg', 0.9);
    const result = await ocr.detect(dataUrl);
    return {
      lines: normalizeLines(result),
      raw: result,
      sourceWidth: source.width,
      sourceHeight: source.height
    };
  }

  function questionStart(text) {
    const line = String(text || '').replace(/\s+/g, ' ').trim();
    if (!line) return false;
    if (/^第\s*[0-9一二三四五六七八九十百]{1,4}\s*题/.test(line)) return true;
    if (/^(?:[0-9]{1,3}|[一二三四五六七八九十百]{1,3})\s*[.．、)）:：]/.test(line)) return true;
    if (/^[一二三四五六七八九十]{1,3}\s*[、.．]/.test(line)) return true;
    return false;
  }

  function groupText(lines) {
    return lines.map(function (line) { return line.text; }).join('\n');
  }

  function regionsFromTexts(lines) {
    if (!Array.isArray(lines) || !lines.length) return [];
    const starts = lines.filter(function (line) { return questionStart(line.text); });
    if (!starts.length) return [];
    const regions = [];
    starts.forEach(function (start, index) {
      const next = starts[index + 1];
      const minY = start.y;
      const maxY = next ? Math.max(minY + 0.03, next.y - 0.012) : 0.985;
      const y = LR.clamp(minY - 0.018, 0.006, 0.98);
      const bottom = LR.clamp(maxY, y + 0.03, 0.99);
      const group = lines.filter(function (line) {
        return line.y >= minY - 0.01 && (!next || line.y < next.y - 0.004);
      });
      regions.push({
        x: 0.012,
        y: y,
        w: 0.976,
        h: bottom - y,
        selected: true,
        ocrText: groupText(group)
      });
    });
    return regions.filter(function (region) { return region.h > 0.015; });
  }

  function linesInRegion(lines, region) {
    return lines.filter(function (line) {
      const cx = line.x + line.w / 2;
      const cy = line.y + line.h / 2;
      return cx >= region.x && cx <= region.x + region.w
        && cy >= region.y && cy <= region.y + region.h;
    });
  }

  function assignTexts(regions, lines) {
    (regions || []).forEach(function (region) {
      if (region.ocrText) return;
      region.ocrText = groupText(linesInRegion(lines || [], region));
    });
    return regions;
  }

  function textForRegion(region, lines) {
    if (!region) return '';
    if (region.ocrText) return region.ocrText;
    return groupText(linesInRegion(lines || [], region));
  }

  function reset() {
    engine = null;
    enginePromise = null;
    revokeUrls();
  }

  LR.ocr = {
    available: available,
    isReady: isReady,
    createEngine: createEngine,
    recognizeCanvas: recognizeCanvas,
    questionStart: questionStart,
    regionsFromTexts: regionsFromTexts,
    assignTexts: assignTexts,
    textForRegion: textForRegion,
    reset: reset
  };
})();
