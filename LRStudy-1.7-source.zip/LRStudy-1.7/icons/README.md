# LRStudy v1.2 图标方案

- `options/options.html`：可交互预览页
- `icon-options.png`：五种方案总览
- `options/a-page-check.svg|png`：A 折页勾（当前默认，已用于 v1.2 APK）
- `options/b-pages.svg|png`：B 双页叠
- `options/c-l-mark.svg|png`：C 极简 L
- `options/d-ring-check.svg|png`：D 圆章勾
- `options/e-bookmark.svg|png`：E 书签

当前安装包使用用户提供的 **LRStudy 彩色图标**（`user-provided-app-icon.jpg` / `final-app-icon.png`）。以下 A–E 为保留的黑白备选方案。
