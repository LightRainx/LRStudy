#!/usr/bin/env python3
"""Build the standalone LRStudy1.7.html from the maintainable web/ source."""
from pathlib import Path
import re
import urllib.parse
import shutil

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "web"
OUT = ROOT / "LRStudy1.7.html"

html = (WEB / "index.html").read_text(encoding="utf-8")
css = (WEB / "css" / "app.css").read_text(encoding="utf-8")
favicon = (WEB / "assets" / "favicon.svg").read_text(encoding="utf-8").strip()
favicon_uri = "data:image/svg+xml," + urllib.parse.quote(favicon, safe="")

html = html.replace('href="assets/favicon.svg"', 'href="' + favicon_uri + '"')
html = html.replace('  <link rel="stylesheet" href="css/app.css">',
                    '  <style>\n' + css + '\n  </style>')

def inline_script(match):
    src = match.group(1)
    code = (WEB / src).read_text(encoding="utf-8")
    return '<script>\n/* ==== ' + src + ' ==== */\n' + code + '\n</script>'

html = re.sub(r'<script src="([^"]+)"></script>', inline_script, html)
banner = "<!-- LRStudy v1.7 standalone build. Source modules: web/css, web/js. -->\n"
html = html.replace("<!DOCTYPE html>", "<!DOCTYPE html>\n" + banner, 1)
OUT.write_text(html, encoding="utf-8")
# Copy web app manifest and home-screen icons alongside the standalone HTML.
(ROOT / "manifest.webmanifest").write_text((WEB / "manifest.webmanifest").read_text(encoding="utf-8"), encoding="utf-8")
site_target = ROOT / "icons" / "site"
site_source = WEB / "assets" / "site"
site_target.mkdir(parents=True, exist_ok=True)
for item in site_source.iterdir():
    if item.is_file():
        shutil.copy2(item, site_target / item.name)
print(f"Built {OUT} ({OUT.stat().st_size:,} bytes)")
