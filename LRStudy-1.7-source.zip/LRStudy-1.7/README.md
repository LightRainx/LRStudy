# LRStudy 1.7 源码

本地优先的错题整理与复习工具，包含网页版源码和 Android WebView 工程。

本仓库不提交 APK；安装包请到 **Releases** 下载（v1.7，versionCode 17）。

## 目录

```text
web/         网页源码（index.html、css、js、assets）
android/     Android WebView 工程，app/src/main/assets 内置网页
tools/       build_html.py，把 web/ 打包成单文件 HTML
icons/       应用图标源文件
```

## v1.7 功能

- 上传题目默认不自动去笔迹；手动去笔迹只处理高饱和红/蓝/绿笔迹，并用周围纸张颜色回填。
- 复习页三种模式：AI 薄弱点组卷、自定义题目、打印错题。
- 自定义题目不依赖错题本，按文字描述让 AI 出题。
- 打印错题可跨错题本选择未掌握题，自动排除已掌握，生成含原题图片和答案解析的打印卷；不保存练习记录。
- 组卷题量上限 100，支持 5 / 10 / 20 / 50 / 100 快捷题量。
- 练习记录、错题本内错题均支持多选删除。
- 在线同步分为「WebDAV 云同步」和「设备间同步」两个可折叠块。

## 构建网页

```bash
python3 tools/build_html.py
```

输出 `LRStudy1.7.html`。构建脚本会同时复制 PWA manifest 和主屏幕图标。

## 构建 Android APK

要求：JDK 17、Android SDK 34、Gradle 8.9。工程内已带 ARM64 构建用的 AAPT2 包装脚本。

```bash
cp LRStudy1.7.html android/app/src/main/assets/
cd android
gradle assembleDebug
```

生成：

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

包名 `com.lrstudy.app`，debug 签名。发布前请使用自己的签名配置，不要把 keystore 或密码提交到仓库。

## 使用

网页版可直接用浏览器打开构建出的 `LRStudy1.7.html`。AI 解析和自定义出题需要先在「设置 → AI 能力」填写 OpenAI 兼容接口、Key 和模型。

## 已知限制

- iOS 网页版不能作为内网/公网同步主机。
- 公网同步依赖 PeerJS 公共信令，连接稳定性不保证。
- 自定义 AI 出题和 100 题组卷的耗时、成功率取决于所使用模型的输出上限。
- 去笔迹仍可能误伤彩色插图；默认关闭，建议先预览再保存。
- Android 原生打印和内网同步尚未在所有机型上验证。

## 版本

当前版本：**v1.7**  
作者：LightRainx
